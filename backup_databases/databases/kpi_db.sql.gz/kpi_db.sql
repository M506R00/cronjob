-- MySQL dump 10.13  Distrib 9.1.0, for Win64 (x86_64)
--
-- Host: localhost    Database: kpi_db
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `kpi_db`
--

/*!40000 DROP DATABASE IF EXISTS `kpi_db`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `kpi_db` /*!40100 DEFAULT CHARACTER SET utf8mb3 */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `kpi_db`;

--
-- Table structure for table `kpitable_tab`
--

DROP TABLE IF EXISTS `kpitable_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kpitable_tab` (
  `kt_id` int NOT NULL AUTO_INCREMENT COMMENT '表單編號(PK)',
  `kt_sortid` int NOT NULL COMMENT '排序用id',
  `kt_psm` varchar(50) NOT NULL COMMENT 'PSM單元',
  `kt_item` varchar(155) NOT NULL COMMENT 'KPI項目',
  `kt_cal` text NOT NULL COMMENT '計算方式',
  `kt_freq` varchar(10) NOT NULL COMMENT '量測頻率',
  `kt_units` varchar(30) NOT NULL COMMENT '提報部門',
  `kt_goal` varchar(30) NOT NULL COMMENT '目標值',
  `kt_note` text NOT NULL COMMENT '備註',
  `kt_judgment` varchar(50) DEFAULT NULL COMMENT '判斷設定(LET實際小於目標/GTE實際大於目標)',
  PRIMARY KEY (`kt_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kpitable_tab`
--

LOCK TABLES `kpitable_tab` WRITE;
/*!40000 ALTER TABLE `kpitable_tab` DISABLE KEYS */;
INSERT INTO `kpitable_tab` VALUES (1,1,'勞工參與(EP)','PSM推動與執行追蹤會議完成率','　召開PSM推動與執行追蹤會議次數\r\n—————————————————   X １００％\r\n　應召開PSM推動與執行追蹤會議次數','季','M506R00','100','100%','GTE'),(2,2,'勞工參與(EP)','檢視權責部門宣導製程安全管理情形','　於會議上製程安全宣導次數\r\n——————————————　Ｘ　１００％\r\n應召開廠務暨擴大安環會議次數','月','M506R00','75','75%','GTE'),(3,3,'勞工參與(EP)','勞工參與計畫完成率','有訂定勞工參與計畫，KPI為100%\r\n有訂定勞工參與計畫，KPI為 0%','年','M506R00','100','100%','GTE'),(4,4,'製程安全資訊(PSI)','檢視SPI有無維持最新狀態','有填寫「製程安全資訊（PSI）定期檢視及更新檢核表」100%\r\n有填寫「製程安全資訊（PSI）定期檢視及更新檢核表」 0%\r\n','年','plantall','100','100%','GTE'),(5,5,'製程危害分析(PHA)','HazOp 五年重評完成率','　已執行五年重評工場數量\r\n——————————————　Ｘ　１００％\r\n當年度應執行五年重評工場數量','年','M506R00','100','100%','GTE'),(6,6,'標準作業程序(SOP)','各工場操作SOP及WI自主審核完成率','有填寫「自訂文件檢視計畫與紀錄」　１００％\r\n無填寫「自訂文件檢視計畫與紀錄」　　０％','年','plantall','100','100%','GTE'),(7,7,'教育訓練(TR)','檢視各部門自辦教育訓練辦理情形','統計當年度自辦教育訓練開班數量','季','M505230','375','每年開班數超過375','SUMQ_GTE'),(8,8,'教育訓練(TR)','檢視廠內工安衛教育訓練辦理情形','統計當年度工安衛教育訓練開班數量','季','M505710','40','每年開班數量超過40班','SUMQ_GTE'),(10,10,'啟動前安全檢查(PSSR)','工場大修啟動前安全檢查完成率','　已執行ＰＳＳＲ工場數量\r\n——————————————　Ｘ　１００％\r\n當年度應執行ＰＳＳＲ工場數量','年','M505710','100','100%','GTE'),(11,11,'機械完整性(MI)','服務申請單設備編號填寫率','服務申請單有確實填寫設備編號數量\r\n————————————————　Ｘ１００％\r\n服務申請單應確實填寫設備編號數量                    \r\n(PS.系統MI自動產出)','季','MIplantall','50','50%','GTE'),(12,12,'動火許可(HWP)','檢視因未落實動火作業管理進而發生製程事故情形','統計當年度因承攬商未落實動火作業管理而發生火災、爆炸等製程事故次數','季','M506R00','0','每年不超過1次','LTE'),(13,13,'變更管理(MOC)','MOC執行完整性','　　　　  MOC超過預定完成日期數量\r\n（１–　———————————————）　Ｘ　１００％\r\n                         MOC執行中數量                      \r\n(PS.系統MOC自動產出)','季','plantall','70','70%','GTE'),(14,14,'變更管理(MOC)','權責部門定期至轄區半粒MOC實地查核','每年至少辦理2次，KPI為100%','年','M506R00','100','100%','GTE'),(15,15,'事故調查(II)','發生製程事故。事故調查報告完成率','已填報製程事故調查報告數量\r\n—————————————　Ｘ　１００％\r\n應填報製程事故調查報告數量','季','M506R00','100','100%','GTE'),(16,16,'緊急應變(EPR)','緊急應變演習完成率','已執行緊急應變演習工場數量\r\n————————————— 　Ｘ　１００％　 \r\n應執行緊急應變演習工場數量','年','M505070','100','100%','GTE'),(17,17,'符合性稽核(CA)','符合性稽核完成率','已執行符合性稽核工場數量\r\n————————————　Ｘ　１００％\r\n應執行符合性稽核工場數量','年','M506R00','100','100%','GTE'),(18,18,'商業機密(TS)','具安全機密防護之指定平台人員使用情形','統計當年度PSM平台登入人數\r\n(PS.系統TS自動產出)','季','M506R00','200','每季PSM平台登入\r\n人數超過200人','GTE'),(19,19,'管理責任(MR)','一級主管參與PSM相關會議之情形','一級主管主持PSM推動與執行追蹤會議次數\r\n———————————————————　Ｘ　１００％\r\n      應召開PSM推動與執行追蹤會議次數','季','M506R00','75','75%\r\n(四季完成，自動除4)','SUMQ_DivisionGET'),(21,9,'承攬商管理(CM)','檢視廠內有無發生承攬商工安意外','統計承攬商發生工作傷害頻率','季','M505710','0.43','傷害頻率不超過0.43/年\r\n(總額再4季後自動除以4)','SUMQ_DivisionLET');
/*!40000 ALTER TABLE `kpitable_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `systemsettings_tab`
--

DROP TABLE IF EXISTS `systemsettings_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `systemsettings_tab` (
  `ss_id` varchar(30) NOT NULL COMMENT '名稱(PK)	',
  `ss_type` varchar(10) NOT NULL COMMENT '輸入類型',
  `ss_value` varchar(255) NOT NULL COMMENT '值',
  `ss_sort` tinyint NOT NULL COMMENT '排序',
  `ss_note` varchar(255) DEFAULT NULL COMMENT '說明',
  PRIMARY KEY (`ss_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `systemsettings_tab`
--

LOCK TABLES `systemsettings_tab` WRITE;
/*!40000 ALTER TABLE `systemsettings_tab` DISABLE KEYS */;
INSERT INTO `systemsettings_tab` VALUES ('supervisors','tags','306339,306355,307297',1,'管理者');
/*!40000 ALTER TABLE `systemsettings_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webpost_tab`
--

DROP TABLE IF EXISTS `webpost_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webpost_tab` (
  `wp_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '鍵值(PK)',
  `wp_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '網站名稱',
  `wp_content` text COMMENT '內容',
  `wp_sort` tinyint NOT NULL COMMENT '排序',
  `wp_ud_id` varchar(30) NOT NULL COMMENT '使用者編號(FK)',
  `wp_datetime` datetime NOT NULL COMMENT '修改時間',
  PRIMARY KEY (`wp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webpost_tab`
--

LOCK TABLES `webpost_tab` WRITE;
/*!40000 ALTER TABLE `webpost_tab` DISABLE KEYS */;
INSERT INTO `webpost_tab` VALUES ('IndexContent','網頁內容','',1,'306355','2025-09-15 14:57:55');
/*!40000 ALTER TABLE `webpost_tab` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-24 13:41:40
