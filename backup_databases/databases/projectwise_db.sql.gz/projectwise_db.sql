-- MySQL dump 10.13  Distrib 9.1.0, for Win64 (x86_64)
--
-- Host: localhost    Database: projectwise_db
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `projectwise_db`
--

/*!40000 DROP DATABASE IF EXISTS `projectwise_db`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `projectwise_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `projectwise_db`;

--
-- Table structure for table `filedata_tab`
--

DROP TABLE IF EXISTS `filedata_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `filedata_tab` (
  `fd_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `fd_name` varchar(255) NOT NULL COMMENT '名稱',
  `fd_department` varchar(11) DEFAULT NULL COMMENT '工場代碼',
  `fd_verse` varchar(11) NOT NULL COMMENT '版本',
  `fd_device` varchar(15) NOT NULL COMMENT '相關設備編號',
  `fd_doctype` varchar(30) NOT NULL COMMENT '文件類型',
  `fd_description` varchar(255) DEFAULT NULL COMMENT '描述',
  `fd_ud_id` varchar(20) NOT NULL COMMENT '申請人(FK)',
  `fd_path` varchar(255) NOT NULL COMMENT '路徑',
  `fd_ReceivedStatus` int NOT NULL COMMENT '是否已領收(1/0)',
  `fd_sort` tinyint NOT NULL COMMENT '排序',
  `fd_status` tinyint DEFAULT '1' COMMENT '狀態(1:啟用,0:禁用)',
  `fd_userphone` int DEFAULT NULL COMMENT '上傳者聯絡分機',
  `fd_createtime` datetime NOT NULL COMMENT '建立時間',
  PRIMARY KEY (`fd_id`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='檔案資料';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filedata_tab`
--

LOCK TABLES `filedata_tab` WRITE;
/*!40000 ALTER TABLE `filedata_tab` DISABLE KEYS */;
INSERT INTO `filedata_tab` VALUES (9,'完工報告_E8024強度計算書(含圖面).pdf','M506E60','110-REP','E-8024再沸器','Technical Data Book','強度計算書','306258','./singleupload/M506E60/16916377008049.pdf',0,1,1,NULL,'2023-08-10 11:21:40'),(10,'T2107103(中油大林)_FINAL(全部).pdf','M506G50','110-REP','E-8024再沸器','Vendor Data Book','設備圖面','306258','./singleupload/M506G50/16916377514669.pdf',0,1,1,NULL,'2023-08-10 11:22:31'),(12,'完工報告_T2107103.REV1-第二冊_0221寄ＭＯ.pdf','M506G50','110-REP','E-8024再沸器','Vendor Data Book','材質證明、端版成型紀錄、熱處理報告、超音波檢測報告、放射線檢測報告、液滲檢測報告、厚度量測表、尺寸檢驗報告、壓力測試報告、試壓照片、噴砂/油漆檢驗報告、名牌、保固書、WPS、PQR、出廠證明、材料製造商認證合格書、構造明細表、熔接明細表、工檢拓印','306258','./singleupload/M506G50/16920825653975.pdf',0,1,1,0,'2023-08-15 14:56:05'),(15,'強度計算書_D2029.pdf','M506D10','108-REP','D-2029廢熱鍋爐','Technical Data Book','強度計算書','306258','./singleupload/M506D10/16923365675481.pdf',0,1,1,0,'2023-08-18 13:29:27'),(36,'12.Q6I12A008交貨文件.zip','M506N20','112-NEW','橋頭供油中心JP-8油槽進口端','平時維修','Q6I12A008交貨文件(橋頭供油中心JP-8油槽進口端-航空燃油前置過濾器組6\"x300#)','306339','./singleupload/M506N20/12.Q6I12A008交貨文件_1720062187.zip',0,1,1,8502,'2024-07-04 11:03:07'),(47,'70273-114-05-001 Rev1.pdf','M506G40','2017-MOD','F-1201','平時維修','CO爐爐管管夾改造','305995','./singleupload/M506G40/70273-114-05-001 Rev1_1723602636.pdf',0,1,1,7198,'2024-08-14 10:30:36'),(48,'70273-114-05-002 Rev1_Sh1.pdf','M506G40','2017-MOD','F-1201','平時維修','CO爐爐管管夾改造','305995','./singleupload/M506G40/70273-114-05-002 Rev1_Sh1_1723602636.pdf',0,1,1,7198,'2024-08-14 10:30:36'),(49,'70273-114-05-002 Rev2_Sh2.pdf','M506G40','2017-MOD','F-1201','平時維修','CO爐爐管管夾改造','305995','./singleupload/M506G40/70273-114-05-002 Rev2_Sh2_1723602636.pdf',0,1,1,7198,'2024-08-14 10:30:36'),(50,'70273-114-05-003 Rev1.pdf','M506G40','2017-MOD','F-1201','平時維修','CO爐爐管管夾改造','305995','./singleupload/M506G40/70273-114-05-003 Rev1_1723602636.pdf',0,1,1,7198,'2024-08-14 10:30:36'),(51,'70273-114-05-004 Rev1_Sh1.pdf','M506G40','2017-MOD','F-1201','平時維修','CO爐爐管管夾改造','305995','./singleupload/M506G40/70273-114-05-004 Rev1_Sh1_1723602636.pdf',0,1,1,7198,'2024-08-14 10:30:36'),(52,'70273-114-05-004 Rev1_Sh2.pdf','M506G40','2017-MOD','F-1201','平時維修','CO爐爐管管夾改造','305995','./singleupload/M506G40/70273-114-05-004 Rev1_Sh2_1723602636.pdf',0,1,1,7198,'2024-08-14 10:30:36'),(53,'70273-114-05-005 Rev1_Sh1.pdf','M506G40','2017-MOD','F-1201','平時維修','CO爐爐管管夾改造','305995','./singleupload/M506G40/70273-114-05-005 Rev1_Sh1_1723602636.pdf',0,1,1,7198,'2024-08-14 10:30:36'),(54,'70273-114-05-005 Rev2_Sh2.pdf','M506G40','2017-MOD','F-1201','平時維修','CO爐爐管管夾改造','305995','./singleupload/M506G40/70273-114-05-005 Rev2_Sh2_1723602636.pdf',0,1,1,7198,'2024-08-14 10:30:36'),(55,'70273-114-05-006 Rev1.pdf','M506G40','2017-MOD','F-1201','平時維修','CO爐爐管管夾改造','305995','./singleupload/M506G40/70273-114-05-006 Rev1_1723602636.pdf',0,1,1,7198,'2024-08-14 10:30:36'),(56,'70273-702-02-001-R1_Method Statement Wavy Bars(安裝說明).pdf','M506G40','2017-MOD','F-1201','平時維修','CO爐爐管管夾改造','305995','./singleupload/M506G40/70273-702-02-001-R1_Method Statement Wavy Bars(安裝說明)_1723602636.pdf',0,1,1,7198,'2024-08-14 10:30:36'),(57,'JW1060209-Q6R06B029-PACKING LIST-1.jpg','M506G40','2017-MOD','F-1201','平時維修','CO爐爐管管夾改造','305995','./singleupload/M506G40/JW1060209-Q6R06B029-PACKING LIST-1_1723602636.jpg',0,1,1,7198,'2024-08-14 10:30:36'),(58,'JW1060209-Q6R06B029-PACKING LIST-2.jpg','M506G40','2017-MOD','F-1201','平時維修','CO爐爐管管夾改造','305995','./singleupload/M506G40/JW1060209-Q6R06B029-PACKING LIST-2_1723602636.jpg',0,1,1,7198,'2024-08-14 10:30:36'),(59,'GAIC201001 ALL DOCUMENT(光碟內容).pdf','M506F60','109-NEW','Q6L09A111雙吸式泵浦P','Technical Data Book','Q6L09A111雙吸式泵浦P1212','266302','./singleupload/M506F60/GAIC201001 ALL DOCUMENT(光碟內容)_1737334023.pdf',1,1,1,7688,'2025-01-20 08:47:03'),(60,'GAIC201001 ALL DOCUMENT(光碟內容).pdf','M506F60','109-NEW','Q6L09A111雙吸式泵浦P','Vendor Data Book','Q6L09A111雙吸式泵浦P1212','266302','./singleupload/M506F60/GAIC201001 ALL DOCUMENT(光碟內容)_1737334148.pdf',1,1,1,7688,'2025-01-20 08:49:08'),(61,'C-7301 加鎖資料-1140519.pdf','M506C70','091-CON','C7301','Technical Data Book','KOBELCO 壓縮機螺絲扭力設定值','305669','./singleupload/M506C70/C-7301 加鎖資料-1140519_1747709615.pdf',1,1,1,7430,'2025-05-20 10:53:35'),(62,'9HDS C-7301A B增設FIRST OUT偵測裝置.pdf','M506C70','114-NEW','C7301','中小工程','C-7301A B電子課裝的FIRST OUT 紀錄器','305669','./singleupload/M506C70/9HDS C-7301A B增設FIRST OUT偵測裝置_1747709734.pdf',1,1,1,7430,'2025-05-20 10:55:34'),(63,'D7702活性碳上蓋版規格.pdf','M506C70','092-CON','D7702','技服備忘錄','D7702活性碳上蓋版','305669','./singleupload/M506C70/D7702活性碳上蓋版規格_1749022902.pdf',1,1,1,7430,'2025-06-04 15:41:42'),(64,'D7702活性碳上蓋版設計圖.pdf','M506C70','092-CON','D7702','技服備忘錄','D7702活性碳上蓋版','305669','./singleupload/M506C70/D7702活性碳上蓋版設計圖_1749022902.pdf',1,1,1,7430,'2025-06-04 15:41:42'),(65,'Q6I13B156-1.GA Drawing Markout_1751010247.pdf','M506C20','113-REP','第十蒸餾工場-F-1001燃燒','正驗驗收資料','Q6I13B156-第十蒸餾工場-F-1001燃燒器配件等(Maker:Zeeco)(採購帶安裝)-113年大修交貨文件','268348','./singleupload/M506C20/Q6I13B156-1.GA Drawing Markout_1751010247.pdf',1,1,1,8502,'2025-06-27 15:44:07'),(66,'Q6I13B156-2.Pilot Drawing Markout(new version )_1751010247.pdf','M506C20','113-REP','第十蒸餾工場-F-1001燃燒','正驗驗收資料','Q6I13B156-第十蒸餾工場-F-1001燃燒器配件等(Maker:Zeeco)(採購帶安裝)-113年大修交貨文件','268348','./singleupload/M506C20/Q6I13B156-2.Pilot Drawing Markout(new version )_1751010247.pdf',1,1,1,8502,'2025-06-27 15:44:07'),(67,'Q6I13B156-3.出廠證明_1751010247.pdf','M506C20','113-REP','第十蒸餾工場-F-1001燃燒','正驗驗收資料','Q6I13B156-第十蒸餾工場-F-1001燃燒器配件等(Maker:Zeeco)(採購帶安裝)-113年大修交貨文件','268348','./singleupload/M506C20/Q6I13B156-3.出廠證明_1751010247.pdf',1,1,1,8502,'2025-06-27 15:44:07'),(68,'Q6I13B156-4.產地證明_1751010247.pdf','M506C20','113-REP','第十蒸餾工場-F-1001燃燒','正驗驗收資料','Q6I13B156-第十蒸餾工場-F-1001燃燒器配件等(Maker:Zeeco)(採購帶安裝)-113年大修交貨文件','268348','./singleupload/M506C20/Q6I13B156-4.產地證明_1751010247.pdf',1,1,1,8502,'2025-06-27 15:44:07'),(69,'Q6I13B156-5.進口報單_1751010247.pdf','M506C20','113-REP','第十蒸餾工場-F-1001燃燒','正驗驗收資料','Q6I13B156-第十蒸餾工場-F-1001燃燒器配件等(Maker:Zeeco)(採購帶安裝)-113年大修交貨文件','268348','./singleupload/M506C20/Q6I13B156-5.進口報單_1751010247.pdf',1,1,1,8502,'2025-06-27 15:44:07'),(70,'Q6I13B156-6.檢驗報告_1751010247.pdf','M506C20','113-REP','第十蒸餾工場-F-1001燃燒','正驗驗收資料','Q6I13B156-第十蒸餾工場-F-1001燃燒器配件等(Maker:Zeeco)(採購帶安裝)-113年大修交貨文件','268348','./singleupload/M506C20/Q6I13B156-6.檢驗報告_1751010247.pdf',1,1,1,8502,'2025-06-27 15:44:07'),(71,'Q6I13B156-7.晉圓 - 安裝說明手冊_1751010247.pdf','M506C20','113-REP','第十蒸餾工場-F-1001燃燒','正驗驗收資料','Q6I13B156-第十蒸餾工場-F-1001燃燒器配件等(Maker:Zeeco)(採購帶安裝)-113年大修交貨文件','268348','./singleupload/M506C20/Q6I13B156-7.晉圓 - 安裝說明手冊_1751010247.pdf',1,1,1,8502,'2025-06-27 15:44:07');
/*!40000 ALTER TABLE `filedata_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `systemsettings_tab`
--

DROP TABLE IF EXISTS `systemsettings_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `systemsettings_tab` (
  `ss_id` varchar(30) NOT NULL COMMENT '名稱(PK)',
  `ss_type` varchar(10) NOT NULL COMMENT '輸入類型',
  `ss_value` varchar(255) NOT NULL COMMENT '值',
  `ss_sort` tinyint NOT NULL COMMENT '排序',
  `ss_note` varchar(255) DEFAULT NULL COMMENT '說明',
  PRIMARY KEY (`ss_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='系統設定';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `systemsettings_tab`
--

LOCK TABLES `systemsettings_tab` WRITE;
/*!40000 ALTER TABLE `systemsettings_tab` DISABLE KEYS */;
INSERT INTO `systemsettings_tab` VALUES ('supervisors','tags','306355,306673,306339',1,'管理者');
/*!40000 ALTER TABLE `systemsettings_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webpost_tab`
--

DROP TABLE IF EXISTS `webpost_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webpost_tab` (
  `wp_id` varchar(100) NOT NULL COMMENT '名稱(PK)',
  `wp_name` varchar(45) NOT NULL COMMENT '網站名稱',
  `wp_content` mediumtext COMMENT '內容',
  `wp_sort` tinyint NOT NULL COMMENT '排序',
  `wp_ud_id` varchar(30) NOT NULL COMMENT '使用者編號(FK)',
  `wp_datetime` datetime NOT NULL COMMENT '修改時間',
  PRIMARY KEY (`wp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='網站內容';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webpost_tab`
--

LOCK TABLES `webpost_tab` WRITE;
/*!40000 ALTER TABLE `webpost_tab` DISABLE KEYS */;
INSERT INTO `webpost_tab` VALUES ('IndexContent','網頁內容',NULL,1,'','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `webpost_tab` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-27 16:00:17
