-- MySQL dump 10.13  Distrib 9.1.0, for Win64 (x86_64)
--
-- Host: localhost    Database: psm_m506b00_db
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `psm_m506b00_db`
--

/*!40000 DROP DATABASE IF EXISTS `psm_m506b00_db`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `psm_m506b00_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `psm_m506b00_db`;

--
-- Table structure for table `articleinfo_tab`
--

DROP TABLE IF EXISTS `articleinfo_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `articleinfo_tab` (
  `ai_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `ai_ai_id` int NOT NULL DEFAULT '0' COMMENT '父層編號(FK)',
  `ai_nb_id` int NOT NULL COMMENT '父層導覽列資料(FK)',
  `ai_title` varchar(255) NOT NULL COMMENT '標題',
  `ai_type` int NOT NULL DEFAULT '1' COMMENT '類型(1:一般資料,2:SDS,4:MOC,8:KELE,16:巡檢表)',
  `ai_content` longtext COMMENT '內容',
  `ai_sort` tinyint NOT NULL COMMENT '排序',
  `ai_status` tinyint NOT NULL COMMENT '狀態(1:啟用,0:禁用)',
  `ai_secret` tinyint NOT NULL DEFAULT '0' COMMENT '機密程度',
  `ai_createtime` datetime NOT NULL COMMENT '建立時間',
  `ai_modifytime` datetime NOT NULL COMMENT '修改時間',
  `ai_ca_year` year DEFAULT '0000' COMMENT '稽核年度',
  `ai_ca_times` tinyint DEFAULT '0' COMMENT '第X次符合性稽核',
  `ai_ca_date` date DEFAULT NULL COMMENT '稽核日期',
  PRIMARY KEY (`ai_id`)
) ENGINE=InnoDB AUTO_INCREMENT=279 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='資料管理';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articleinfo_tab`
--

LOCK TABLES `articleinfo_tab` WRITE;
/*!40000 ALTER TABLE `articleinfo_tab` DISABLE KEYS */;
INSERT INTO `articleinfo_tab` VALUES (1,80,1,'1-1 危害性化學品清單',1,'',1,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(2,82,1,'3-2 危險區域劃分圖',1,'',2,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(3,82,1,'3-4 沖身洗眼器與公用站位置圖',1,'',4,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(4,80,1,'1-2 安全資料表(SDS)',2,'',2,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(5,82,1,'3-10 迴路接線圖',1,'<a href=\"http://10.20.82.100\" target=\"_blank\">中油圖面管理查詢系統</a>',10,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(6,82,1,'3-5 現場氣體偵測器位置圖',1,'',5,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(7,82,1,'3-3 場區布置圖',1,'',3,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(8,82,1,'3-11 電氣單線圖',1,'',11,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(9,82,1,'3-1 管路及儀表流程圖(PID)',1,'<p><a href=\"http://10.20.91.69/CPCEDM2/DS00010/DS00010MF.aspx\" target=\"_blank\">中油大林廠圖庫管理系統</a>(<u><span style=\"color:#4C33E5;\">新系統</span></u>，依指示登入後，請點選<span style=\"color:#E53333;\">\"進階搜尋\"</span><b>選擇\"工場\"</b>及\"<b>設計類別\"=\"G12流程圖表\"</b>後搜尋)</p><p><a href=\"http://10.20.91.69/cpsm/CMF/SForm.aspx?url=..%2fCM0030%2fCM0030MF.aspx&fcid=6A00\" target=\"_blank\">P&ID索引表</a></p>',1,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(11,81,1,'2-2 製程化學反應資料',1,'',2,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(12,82,1,'3-8 製程安全連鎖因果矩陣圖',1,'',8,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(13,81,1,'2-3 製程安全評估資料',1,'',3,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(14,81,1,'2-1 製程流程圖(PFD)',1,'<a href=\"http://10.20.91.69/cpsm/CMF/SForm.aspx?url=../CM0030/CM0030MF.aspx&fcid=6A00\" target=\"_blank\">中油大林廠圖庫管理系統</a>',1,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(15,82,1,'3-7 製程設計規範及標準',1,'',7,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(16,82,1,'3-6 製程設備製造規格',1,'',6,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(17,81,1,'2-4 製程操作條件管制上、下限',1,'',4,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(18,81,1,'2-5 製程說明',1,'',5,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(19,81,1,'2-6 質能平衡表',1,'',6,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(20,82,1,'3-12 釋壓系統設計書(PSV)',1,'',12,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(26,0,4,'1 初始開俥操作程序',1,'',4,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(27,0,4,'2 正常操作程序',1,'',5,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(28,0,4,'3 臨時操作程序',1,'',6,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(29,0,4,'4 緊急停俥條件及程序',1,'',7,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(30,0,4,'5 緊急操作程序',1,'',8,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(31,0,4,'6 正常停俥操作程序',1,'',9,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(32,0,4,'7 歲修或緊急停俥後之重新開俥',1,'',10,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(33,0,7,'PSSR開爐前工安查核',1,'',1,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(34,82,1,'3-9 Logic Diagrams控制邏輯圖',1,'',9,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(35,88,2,'1-1 HazOp危害與可操作性分析',1,'HazOp危害與可操作性分析',1,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(36,88,2,'1-2 FMEA失效模式影響分析',1,'FMEA失效模式影響分析',2,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(37,88,2,'1-3 FTA失誤樹分析',1,'FTA失誤樹分析',3,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(38,0,2,'二、PrHA初步危害分析',1,'',2,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(39,0,2,'三、LOPA保護層分析',1,'',3,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(40,0,8,'一、SCE安全關鍵性設備',1,'',2,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(41,89,8,'2-1 腐蝕環路手冊',1,'',1,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(42,89,8,'2-2 RBI風險基準檢查報告',1,'',2,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(43,89,8,'2-3 檢測規劃報告',1,'',3,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(44,0,8,'三、SIS安全儀表系統SIL安全完整性等級',1,'',4,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(45,90,8,'4-1 設備檢查',1,'',1,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(46,90,8,'4-2 機械修理',1,'',2,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(47,90,8,'4-3 電氣設備',1,'',3,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(48,90,8,'4-4 轉動機械',1,'',4,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(49,90,8,'4-5 儀器電子',1,'',5,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(50,91,8,'5-2 管線材質規範',1,'',2,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(51,91,8,'5-1 管線清單',1,'',1,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(52,0,8,'六、設備延長使用替代檢查',1,'',7,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(53,0,11,'製程事故簡報',1,'',1,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(54,0,11,'工安事故簡報',1,'',2,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(57,14,1,'方塊流程圖(BFD)',1,'',1,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(68,0,13,'113年度符合性稽核計畫',1,'',1,1,0,'2024-11-28 10:00:50','2024-11-28 10:00:50',NULL,NULL,NULL),(69,68,13,'稽核缺失改善追蹤紀錄表',32,'',1,1,0,'2024-11-28 10:00:50','2025-07-10 13:54:01',2024,3,'2024-11-12'),(70,0,10,'大林煉油廠 變更管理總覽表',4,'',1,1,0,'2025-06-04 12:00:00','2025-07-23 08:07:51',0000,0,'0000-00-00'),(80,0,1,'一、化學品資訊',1,'化學品資訊',2,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(81,0,1,'二、製程技術資訊',1,'製程技術資訊',3,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(82,0,1,'三、製程設備資訊',1,'製程設備資訊',4,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(88,0,2,'一、製程危害分析',1,'',1,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(89,0,8,'二、腐蝕環路&RBI風險基準檢查',1,'',3,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(90,0,8,'四、ITPM檢查測試預防保養',1,'',5,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(91,0,8,'五、管線',1,'',6,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(92,0,8,'七、各類設備基本資料表',1,'',8,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(93,40,8,'1-1 SCE安全關鍵性設備清單',1,'',1,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(94,40,8,'1-2 SCE安全關鍵性管線清單',1,'',2,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(95,0,10,'大林煉油廠 管理/閥件/設備克漏登錄管制表',8,'',2,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(96,0,20,'簡介',1,'<p align=\"left\" style=\"text-align:left;\">\n	工場大事紀為收集、記錄及保存<span style=\"color:#E53333;\">各操作部門發生過有關工安、環保、停產、財損等異常狀況或重大問題</span>，以傳承的角度提供後來接班者快速學習過去之改善方案或問題解決之經驗及參考案例，以精進員工更安全操作的環境。<span></span> \n</p>',1,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(117,0,1,'PSI部門定期檢視及更新紀錄',1,'',1,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(121,90,8,'4-6 轉動機械保養專責認養表',1,'',6,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(125,95,10,'大林煉油廠 管線/設備克漏每月定期巡檢表',16,'',1,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(129,0,4,'設備管線操作圖資',1,'',2,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(131,40,8,'1-3 關鍵性固定設備及管線',1,'',3,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(132,40,8,'1-4 關鍵性轉動機械',1,'',4,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(133,40,8,'1-5 關鍵性儀控設備',1,'',5,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(134,82,1,'3-13 設備管線操作圖資',1,'',13,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(135,0,4,'8 歲修作業程序',1,'',11,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(146,82,1,'3-14 盲板圖',1,'',14,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(155,82,1,'3-15 Cross Book(FTA和DCS卡片配置)',1,'',15,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(160,88,2,'製程安全評估分區分時段規劃',1,'',4,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(167,81,1,'2-7 製程儀器管制點清單',1,'',7,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(251,0,6,'作業環境危害告知',1,'',1,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(252,0,6,'承攬商作業工作安全分析(JSA)-一般性',1,'',2,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(253,0,6,'承攬商作業工作安全分析(JSA)-特殊',1,'',3,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(258,0,4,'緊急停爈判斷指引',1,'',3,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(259,0,4,'大林煉油廠操作程序管理準則',1,'<a href=\"http://tlsweb.cpc.com.tw/m50/iso/6R00/6R0-PSM-04.docx\" target=\"_blank\">大林煉油廠操作程序管理準則</a>',1,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(260,0,8,'年度大修計劃',1,'<a href=\"http://home/a0200web/source/總工SOP/工場大修管理手冊/工場大修管理手冊修訂2版.doc\" target=\"_blank\">工場大修管理手冊</a>(總工程師室)<br />\n<span style=\"color:#E53333;\"><strong>※請將歷年歲修項目(固定檔/變動檔)存放於此</strong></span>',1,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(266,0,8,'八、大修檢查資料',1,'',9,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(270,0,9,'A級動火會議',1,'',1,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(271,0,3,'維持正常操作精進作為',1,'',1,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(272,0,20,'工場五年內重要事件',1,'',2,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(273,272,20,'製程變更設計',1,'',1,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(274,272,20,'工安環保事件',1,'',2,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(275,272,20,'小班教學',1,'',3,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(276,272,20,'大修檢討',1,'',4,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(277,272,20,'虛驚事件',1,'',5,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL),(278,272,20,'設備維修紀錄',1,'',6,0,0,'2024-12-01 00:00:00','2024-12-01 00:00:00',0000,0,NULL);
/*!40000 ALTER TABLE `articleinfo_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `complianceaudit_tab`
--

DROP TABLE IF EXISTS `complianceaudit_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `complianceaudit_tab` (
  `ca_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `ca_ai_id` int NOT NULL COMMENT '文章編號(FK)',
  `ca_ud_id` varchar(30) NOT NULL COMMENT '人員編號(FK)',
  `ca_nb_id` int NOT NULL DEFAULT '0' COMMENT 'PSM單元(FK)',
  `ca_type` tinyint NOT NULL DEFAULT '0' COMMENT '類別(0:不符合事項,1:建議改進事項)',
  `ca_deficiency` mediumtext NOT NULL COMMENT '稽核缺失',
  `ca_expected_content` mediumtext COMMENT '預計改善方式',
  `ca_expected_date` date DEFAULT NULL COMMENT '預計改善日期',
  `ca_expected_signature` mediumtext COMMENT '預計改善負責人',
  `ca_actual_content` mediumtext COMMENT '改善結果確認',
  `ca_actual_date` date DEFAULT NULL COMMENT '實際改善日期',
  `ca_actual_signature` mediumtext COMMENT '實際改善負責人',
  `ca_datetime` datetime NOT NULL COMMENT '建立時間',
  PRIMARY KEY (`ca_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='符合性稽核';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `complianceaudit_tab`
--

LOCK TABLES `complianceaudit_tab` WRITE;
/*!40000 ALTER TABLE `complianceaudit_tab` DISABLE KEYS */;
INSERT INTO `complianceaudit_tab` VALUES (1,69,'118770',15,1,'經稽核發現，主管雖透過LINE宣導製程安全及工安資訊，但已久未召開組務會議，為確保有效溝通，建議未來至少每月召開一次組務會議。','依稽核之建議辦理','2025-07-10','<img class=\"signature\" src=\"data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI1MCIgaGVpZ2h0PSI1MCIgZGF0YS11ZF9pZD0iMjkyMDQ0Ij4NCiAgPHJlY3Qgd2lkdGg9IjUwIiBoZWlnaHQ9IjM3LjUiIHN0eWxlPSJmaWxsOiNmZmY7c3Ryb2tlLXdpZHRoOjEuNjY2NjY2NjY2NjY2NztzdHJva2U6cmVkOyIvPg0KICA8dGV4dCBjbGFzcz0iZGVwYXJ0bWVudCIgeD0iMiIgeT0iMTAiIGZvbnQtZmFtaWx5PSJERkthaS1TQiIgZm9udC1zaXplPSIxMS42NjY2NjY2NjY2NjciIGZpbGw9InJlZCIgdGV4dExlbmd0aD0iNDYiPuWFrOeUqOe1hDwvdGV4dD4NCiAgPHRleHQgY2xhc3M9InRpdGxlIiB4PSIyIiB5PSIyMS42NjY2NjY2NjY2NjciIGZvbnQtZmFtaWx5PSJERkthaS1TQiIgZm9udC1zaXplPSIxMS42NjY2NjY2NjY2NjciIGZpbGw9InJlZCIgdGV4dExlbmd0aD0iNDYiPuW3peeoi+W4qzwvdGV4dD4NCiAgPHRleHQgY2xhc3M9Im5hbWUiIHg9IjIiIHk9IjMzLjMzMzMzMzMzMzMzMyIgZm9udC1mYW1pbHk9IkRGS2FpLVNCIiBmb250LXNpemU9IjExLjY2NjY2NjY2NjY2NyIgZmlsbD0icmVkIiB0ZXh0TGVuZ3RoPSI0NiI+5p6X5oGG6KOVPC90ZXh0Pg0KICA8dGV4dCBjbGFzcz0iZGF0ZXRpbWUiIHg9IjAiIHk9IjQ2LjY2NjY2NjY2NjY2NyIgZm9udC1zaXplPSIxMCIgdGV4dExlbmd0aD0iNTAiPjExNDA3MTAxMzUxPC90ZXh0Pg0KPC9zdmc+\"alt=\"2025-07-10 13:51:26\" title=\"2025-07-10 13:51:26\" />','在公用組部門園地有上載組務會議114年6月份組務會議','2025-07-10','<img class=\"signature\" src=\"data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI1MCIgaGVpZ2h0PSI1MCIgZGF0YS11ZF9pZD0iMjkyMDQ0Ij4NCiAgPHJlY3Qgd2lkdGg9IjUwIiBoZWlnaHQ9IjM3LjUiIHN0eWxlPSJmaWxsOiNmZmY7c3Ryb2tlLXdpZHRoOjEuNjY2NjY2NjY2NjY2NztzdHJva2U6cmVkOyIvPg0KICA8dGV4dCBjbGFzcz0iZGVwYXJ0bWVudCIgeD0iMiIgeT0iMTAiIGZvbnQtZmFtaWx5PSJERkthaS1TQiIgZm9udC1zaXplPSIxMS42NjY2NjY2NjY2NjciIGZpbGw9InJlZCIgdGV4dExlbmd0aD0iNDYiPuWFrOeUqOe1hDwvdGV4dD4NCiAgPHRleHQgY2xhc3M9InRpdGxlIiB4PSIyIiB5PSIyMS42NjY2NjY2NjY2NjciIGZvbnQtZmFtaWx5PSJERkthaS1TQiIgZm9udC1zaXplPSIxMS42NjY2NjY2NjY2NjciIGZpbGw9InJlZCIgdGV4dExlbmd0aD0iNDYiPuW3peeoi+W4qzwvdGV4dD4NCiAgPHRleHQgY2xhc3M9Im5hbWUiIHg9IjIiIHk9IjMzLjMzMzMzMzMzMzMzMyIgZm9udC1mYW1pbHk9IkRGS2FpLVNCIiBmb250LXNpemU9IjExLjY2NjY2NjY2NjY2NyIgZmlsbD0icmVkIiB0ZXh0TGVuZ3RoPSI0NiI+5p6X5oGG6KOVPC90ZXh0Pg0KICA8dGV4dCBjbGFzcz0iZGF0ZXRpbWUiIHg9IjAiIHk9IjQ2LjY2NjY2NjY2NjY2NyIgZm9udC1zaXplPSIxMCIgdGV4dExlbmd0aD0iNTAiPjExNDA3MTAxMzU0PC90ZXh0Pg0KPC9zdmc+\"alt=\"2025-07-10 13:54:01\" title=\"2025-07-10 13:54:01\" />','2025-07-10 13:54:01');
/*!40000 ALTER TABLE `complianceaudit_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filedata_tab`
--

DROP TABLE IF EXISTS `filedata_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `filedata_tab` (
  `fd_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `fd_ai_id` int NOT NULL COMMENT '資料編號(FK)',
  `fd_km_id` int DEFAULT '0' COMMENT '克漏編號(FK)',
  `fd_name` varchar(255) NOT NULL COMMENT '名稱',
  `fd_description` varchar(255) DEFAULT NULL COMMENT '描述',
  `fd_path` varchar(255) NOT NULL COMMENT '路徑',
  `fd_fulltext` mediumtext COMMENT '全文檢索',
  `fd_sort` tinyint NOT NULL COMMENT '排序',
  `fd_status` tinyint DEFAULT '1' COMMENT '狀態(1:啟用,0:禁用)',
  `fd_createtime` datetime NOT NULL COMMENT '建立時間',
  PRIMARY KEY (`fd_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='檔案資料';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filedata_tab`
--

LOCK TABLES `filedata_tab` WRITE;
/*!40000 ALTER TABLE `filedata_tab` DISABLE KEYS */;
INSERT INTO `filedata_tab` VALUES (1,69,0,'大林煉油廠公用組114年6月組務會議紀錄.pdf','依稽核建議辦理','./files/M506B00/69/17521260532676.pdf','大林煉油廠公用組114年6月組務會議紀錄日期114年6月30日13時30分地點公用組會議室主席曹永吉經理出席公用組林恆裕第一動力工場劉健男郭原良陳錦成傅統營第二動力工場鄭莫輝張軒維鐘卓峰李居福供電工場陳奕劭洪錫賢紀錄鍾卓峰蹈庄52一政今宣導1自114年了月1日起大林廠提出之採購絞件需先經大林廠購審會審議通過後方可送南採辦理後續採購程序2同仁進出大門應先降低車速出示員工識別證以利係全人員柏驗放行3上級機關葫廠視察時應派出職務對等之人員陪同並同步對視察內容進行解說小請同仁多加利用時間進倫以加強提升外語能力5因工安處查核認為本廠工場環境尚有須改善的地方各轄區須加強5S管理6近來天氣炎熱請多加留意同仁及承攬商工作狀況工作時要特別留意避免熱危家問題發生7各部門持續推動職場不法侵害及性騷擾防治各級主管處理類似索件時應審慎以對8依勞動部5月14日有機溶劑中毒預防規則第23條倬正條文規定請各工場於作業場所顯明易見之處揭示森止勞工在有機溶劑作素場所吸茨或飲食9國內進入登革熱流行期為降低登革熱流行風險應加強所屬人員登革熱防治教肖宣導及落實權管場域環境管理及孳生源清除工作經濟部國營司將登革熱防治辦理情形納入公司年度工作考成參考10如有陸籍含港澳人士欲進廠從事商素活動務必事先簽陳廠長並加會政風組以落實審核程序須經廠長核定始能效行二工安衛生PSM與環係宣導1重申環係空汙事件應於易常發生後1小時內務必通知高雄市環係局稽查科2本廠全廠區內均為綸菸區綦止所有人員在廠區內吸菸3近期有發生承攪商遭蜇蟄事件各工場如有從事戶外工作及易與動植物接觸之工作者安全衛生管理於作維前先做好作緒環境危家辨識及評估採取動植物以及熱卵家預防之必要措施4近期新冠及登革熟疲情嚴峻同仁進出共場所請戴口罩並做好個人防護入後徹底清除積水避免病嫘蚊孳生5因天氣災熱請承攬商多補充水分並填寫熱危害檢點表6迎期適逢兩季請同仁注意自身及於工承攬商人員安全於簽發許可證工安叮嚀時提醒承攬商於作時應考量強風大入及雷擊等危宮以人員安全為第一優先考量必要時應先予停工並使人員退避至安全場所仁請各工場依總公司環係處要求改以桶裝收集庄澗滾油並依環係法規標示與儲存落實事素廢紊物管理8安環工程師進行安環宣導一大倫期間特別是開停爐階段請同仁特別留意關鍵性步驃需按部就班執行不可輕易踞忽並確實落實八大係命條款及現場5S管理二工安做得好好運跟著來主管要勤加走動管理三請同仁上下班時勿趕時間注意交通安全為第一優先考量四未來工安處查核可能會有無預警演習故平常演習時就要先將相關計畫先擬定五依據工安分級查核實施要點現場主管於危險時刻1130120U15301630應加強現場巡查與督導六分級查核之內容填具及改善等填寫方式請主管向同仁加強宣導七有關已辦理超遇五年之索件辦理已展延又將逾期的M0C絨件目前仍處於工務設計階段建請轄區與工務組研討是否有施作之必要性三討論及決議事項1B407鍋爐訂於7月9日起停爐大倬準備月14至8月3日大修預計8/7完成開爐送汽期間請確實遵守工安規定如期如質順利完成大倬工作2209水塔水溫高溫差縮小問題已於6/19配合六嫋停爐大倍關閉一室入內查看確認因忤/妻嫘組製程洩滋致散水材堵塞造成請二動依6/11會議決議儔速進行散水材後續緊忤更新相關作紙程序並持續配合煉三/煉五組微底查出所有洩滋源阻斷之3前DU4排效SS超標問題環係局要求改善事項中本組須於一二動增設SS分析儀已分別如期提出中小工程後續請持續追蹤進度4本廠近幾年因工場開工率較低年用水量已連續2年未達用水計畫八成若今年仍未達標將面臨被調降用水計晝量請一二動研擬方絨因應必要時請廠方協助5小額發絨報銷應考慮必要性合理性與真實性等三個面向6社交工程演練已改為無預警測試請同仁應養成不任意開啟來路不明郵件之習慣7IS01400145001/TO0SHMS外部稽核於6/206/27進行本組無被查出任何缺點這都是同仁平日按部就班別力的展現芳菊繼續維持並期期更加精進8公司為落實任滿3至6年人員輪調作素自7月1日起公用組經理與儀電組經理職務互換愚謝六年來大家鼎力幫忙與支持使得公用組素務順利推行期朝公用組在新任金經理帶領下益創縣光四重點工作追蹤事項1第一動力工場1B409鍋爐燃料氣K0DRUM更新放大新設D901B工程索槽體已驗收完成管線基座設計完成儀器部分已採購完成2坊1超純水設備採購待安裝索由工務組辦理目前設計規劃中3染油消防泵FP08中小工程絞已洽廠商提供相關資料工務組辦理中4第二原水站T-9021/T-9022水槻16SLEKEKSRMMRMOVTHE號TSE09059規範已完成已辦理公開徵求目前有一家廠商報價近期提出請購電工管線部分待決標後才能設計審查日期109/6/55B4D4鍋爐燃氣緩衛槽T601汰舊換新工程索號TSE11U15槽體規範及報價皆完成後續簽核完後送南採管線及儀器設計尚有部分要修改審查日期111/2/252第二動力工場1二動T7002/T7003飲用水槽採購帶安裝索索號Q6L10AU81由工務組辦理發包完成營繕課監造副本圖套繪圖雜項執照已完成後續待廠商辦理營造牌才能於工2329冷卻水塔遇濾砂更換工作MGE1350058目前執行更換作松中3B-406鍋爐更換為低氫氣化物燃燒器工務組辦理中4B-406鍋爐送風機節能改善工務組辦理中5第二動力工場29與30水塔加裝SS線上分析儀工務組辦理中3供電工場1二橋變電所功率因數改善絨目前由工務組設計規劃中2161kV變電所TR101/TR102容量擴充工程索由工務組辦理中預計114/08送台電圖審3新第一變電所之增建電梯工程絨由工務組辦理目前設計規劃中4其他工作由各工場自行列表追蹤陳經理曹LoFZoeaac副廠長李PedimeeejW',1,1,'2025-07-10 13:40:53');
/*!40000 ALTER TABLE `filedata_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `keleanswer_tab`
--

DROP TABLE IF EXISTS `keleanswer_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `keleanswer_tab` (
  `ka_km_id` int NOT NULL COMMENT '克漏編號(PK)',
  `ka_kq_id` int NOT NULL COMMENT '題目編號(FK)',
  `ka_ud_id` varchar(30) NOT NULL COMMENT '人員編號(FK)',
  `ka_ot_id` varchar(50) DEFAULT NULL COMMENT '選項編號(FK)',
  `ka_note` text COMMENT '備註',
  `ka_datetime` datetime NOT NULL COMMENT '建立時間',
  PRIMARY KEY (`ka_km_id`,`ka_kq_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='答案';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `keleanswer_tab`
--

LOCK TABLES `keleanswer_tab` WRITE;
/*!40000 ALTER TABLE `keleanswer_tab` DISABLE KEYS */;
/*!40000 ALTER TABLE `keleanswer_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kelemanagement_tab`
--

DROP TABLE IF EXISTS `kelemanagement_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kelemanagement_tab` (
  `km_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `km_ud_id` varchar(30) NOT NULL COMMENT '人員編號(FK)',
  `km_no` varchar(50) DEFAULT NULL COMMENT '克漏編號',
  `km_asset_no` text COMMENT '克漏設備/管線編號',
  `km_position` varchar(100) DEFAULT NULL COMMENT '洩漏位置',
  `km_contents` text COMMENT '主要內容物',
  `km_cause` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '洩漏可能原因',
  `km_note` text COMMENT '應變對策說明',
  `km_estimate_date` varchar(15) DEFAULT NULL COMMENT '預估回復日期',
  `km_kele_date` varchar(15) DEFAULT NULL COMMENT '克漏日期',
  `km_kele_signature1` mediumtext COMMENT '克漏完成簽名',
  `km_kele_signature2` mediumtext COMMENT '克漏工場長審核',
  `km_kele_signature3` mediumtext COMMENT '克漏經理核定',
  `km_recover_date` varchar(15) DEFAULT NULL COMMENT '回復日期',
  `km_recover_signature1` mediumtext COMMENT '回復確認簽名',
  `km_recover_signature2` mediumtext COMMENT '回復工場長審核',
  `km_recover_signature3` mediumtext COMMENT '回復經理核定',
  `km_version` tinyint NOT NULL DEFAULT '1' COMMENT '版次',
  `km_datetime` datetime NOT NULL COMMENT '建立時間',
  PRIMARY KEY (`km_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='克漏管理';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kelemanagement_tab`
--

LOCK TABLES `kelemanagement_tab` WRITE;
/*!40000 ALTER TABLE `kelemanagement_tab` DISABLE KEYS */;
/*!40000 ALTER TABLE `kelemanagement_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `navbar_tab`
--

DROP TABLE IF EXISTS `navbar_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `navbar_tab` (
  `nb_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `nb_nb_id` int NOT NULL DEFAULT '0' COMMENT '父層編號(FK)',
  `nb_name` varchar(255) NOT NULL COMMENT '名稱',
  `nb_sort` tinyint NOT NULL DEFAULT '1' COMMENT '排序',
  `nb_status` tinyint NOT NULL DEFAULT '1' COMMENT '狀態(1:啟用,0:禁用)',
  PRIMARY KEY (`nb_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='PSM要素';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `navbar_tab`
--

LOCK TABLES `navbar_tab` WRITE;
/*!40000 ALTER TABLE `navbar_tab` DISABLE KEYS */;
INSERT INTO `navbar_tab` VALUES (1,0,'製程安全資訊(PSI)',1,1),(2,0,'製程危害控制措施(PHA)',2,1),(3,0,'員工參與(EP)',3,1),(4,0,'操作程序(OP)',4,1),(5,0,'教育訓練(TR)',5,1),(6,0,'承攬商管理(CM)',6,1),(7,0,'啟動前安全檢查(PSSR)',7,1),(8,0,'設備完整性(MI)',8,1),(9,0,'動火許可(HWP)',9,1),(10,0,'變更管理(MOC)',10,1),(11,0,'事故調查(II)',11,1),(12,0,'緊急應變(EPR)',12,1),(13,0,'符合性稽核(CA)',13,1),(14,0,'商業機密(TS)',14,1),(15,0,'管理責任(MR)',15,0),(20,0,'大事紀(IM)',16,1);
/*!40000 ALTER TABLE `navbar_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recordmodify_tab`
--

DROP TABLE IF EXISTS `recordmodify_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recordmodify_tab` (
  `rm_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `rm_ud_id` varchar(30) NOT NULL COMMENT '使用者編號(FK)',
  `rm_nb_id` int NOT NULL DEFAULT '0' COMMENT 'PSM要素編號(FK)',
  `rm_ai_id` int NOT NULL DEFAULT '0' COMMENT '資料編號(FK)',
  `rm_fd_id` int NOT NULL DEFAULT '0' COMMENT '檔案編號(FK)',
  `rm_action` enum('N','E','D','C','M') NOT NULL COMMENT '動作(N:New,E:Edit,D:Delete,C:Change,M:Move)',
  `rm_rt_id` int NOT NULL COMMENT '文章標題編號(FK)',
  `rm_ip` varchar(255) NOT NULL COMMENT 'IP',
  `rm_datetime` datetime NOT NULL COMMENT '建立時間',
  PRIMARY KEY (`rm_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='編輯紀錄';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recordmodify_tab`
--

LOCK TABLES `recordmodify_tab` WRITE;
/*!40000 ALTER TABLE `recordmodify_tab` DISABLE KEYS */;
INSERT INTO `recordmodify_tab` VALUES (1,'292044',0,69,1,'N',4,'10.20.25.210','2025-07-10 13:40:53'),(2,'292044',0,69,1,'E',4,'10.20.25.210','2025-07-10 13:43:00');
/*!40000 ALTER TABLE `recordmodify_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recordtitle_tab`
--

DROP TABLE IF EXISTS `recordtitle_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recordtitle_tab` (
  `rt_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `rt_name` varchar(255) NOT NULL COMMENT '標題名稱',
  PRIMARY KEY (`rt_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='標題紀錄';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recordtitle_tab`
--

LOCK TABLES `recordtitle_tab` WRITE;
/*!40000 ALTER TABLE `recordtitle_tab` DISABLE KEYS */;
INSERT INTO `recordtitle_tab` VALUES (1,'稽核缺失改善追蹤紀錄表'),(2,'113年度符合性稽核計畫'),(3,'大林煉油廠 變更管理總覽表'),(4,'符合性稽核(CA) > 稽核缺失改善追蹤紀錄表 > 大林煉油廠公用組114年6月組務會議紀錄.pdf');
/*!40000 ALTER TABLE `recordtitle_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recordview_tab`
--

DROP TABLE IF EXISTS `recordview_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recordview_tab` (
  `rv_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `rv_ud_id` varchar(30) NOT NULL COMMENT '使用者編號(FK)',
  `rv_ai_id` int NOT NULL COMMENT '文章編號(FK)',
  `rv_rt_id` int NOT NULL COMMENT '文章標題編號(FK)',
  `rv_datetime` datetime NOT NULL COMMENT '建立時間',
  PRIMARY KEY (`rv_id`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='觀看記錄';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recordview_tab`
--

LOCK TABLES `recordview_tab` WRITE;
/*!40000 ALTER TABLE `recordview_tab` DISABLE KEYS */;
INSERT INTO `recordview_tab` VALUES (1,'306355',69,1,'2024-12-11 13:14:53'),(2,'306355',69,1,'2024-12-11 13:44:06'),(3,'306355',69,1,'2024-12-11 14:54:05'),(4,'306355',69,1,'2024-12-12 09:53:10'),(5,'306355',68,2,'2024-12-12 09:53:13'),(6,'306355',69,1,'2024-12-12 09:53:15'),(7,'306355',69,1,'2024-12-13 10:36:38'),(8,'118770',69,1,'2024-12-26 15:35:04'),(9,'118770',69,1,'2024-12-27 14:05:44'),(10,'118770',69,1,'2024-12-27 14:06:15'),(11,'118770',69,1,'2024-12-27 14:07:13'),(12,'118770',69,1,'2024-12-27 14:07:16'),(13,'306355',69,1,'2024-12-27 15:55:59'),(14,'307254',68,2,'2025-01-23 14:56:09'),(15,'306355',69,1,'2025-02-04 08:29:40'),(16,'307327',69,1,'2025-03-19 11:32:57'),(17,'118770',69,1,'2025-03-20 09:33:31'),(18,'292044',68,2,'2025-03-20 15:22:05'),(19,'292044',69,1,'2025-03-20 15:22:12'),(20,'292044',69,1,'2025-03-20 15:26:53'),(21,'292044',69,1,'2025-03-20 15:27:44'),(22,'292044',69,1,'2025-03-20 15:28:08'),(23,'292044',69,1,'2025-03-20 15:28:16'),(24,'292044',69,1,'2025-03-20 15:36:14'),(25,'292044',68,2,'2025-03-21 08:21:35'),(26,'292044',68,2,'2025-03-21 08:22:13'),(27,'292044',69,1,'2025-03-21 08:22:18'),(28,'292044',69,1,'2025-03-21 08:23:02'),(29,'292044',69,1,'2025-03-21 08:24:33'),(30,'292044',69,1,'2025-03-21 08:24:40'),(31,'118770',69,1,'2025-03-24 09:18:51'),(32,'306355',69,1,'2025-04-17 09:33:55'),(33,'292044',69,1,'2025-05-08 08:05:41'),(34,'307327',70,3,'2025-06-06 15:34:22'),(35,'306355',70,3,'2025-06-06 15:36:14'),(36,'307327',70,3,'2025-06-06 15:36:19'),(37,'308498',68,2,'2025-06-26 09:57:05'),(38,'118770',69,1,'2025-07-03 09:54:44'),(39,'118770',69,1,'2025-07-03 09:57:13'),(40,'118770',69,1,'2025-07-10 10:21:57'),(41,'292044',69,1,'2025-07-10 13:22:23'),(42,'292044',69,1,'2025-07-10 13:25:47'),(43,'292044',69,1,'2025-07-10 13:25:54'),(44,'292044',69,1,'2025-07-10 13:27:56'),(45,'292044',69,1,'2025-07-10 13:31:36'),(46,'292044',69,1,'2025-07-10 13:31:37'),(47,'292044',69,1,'2025-07-10 13:32:21'),(48,'292044',69,1,'2025-07-10 13:40:58'),(49,'292044',69,1,'2025-07-10 13:43:01'),(50,'292044',69,1,'2025-07-10 13:43:06'),(51,'292044',69,1,'2025-07-10 13:43:17'),(52,'292044',69,1,'2025-07-10 13:43:22'),(53,'292044',69,1,'2025-07-10 13:44:06'),(54,'118770',68,2,'2025-07-10 13:46:50'),(55,'118770',69,1,'2025-07-10 13:46:52'),(56,'118770',69,1,'2025-07-10 13:47:12'),(57,'292044',69,1,'2025-07-10 13:54:18'),(58,'292044',69,1,'2025-07-10 13:54:23'),(59,'306355',70,3,'2025-07-18 14:31:44'),(60,'306355',70,3,'2025-07-18 14:32:21'),(61,'305103',69,1,'2025-07-22 13:09:59'),(62,'305103',70,3,'2025-07-22 14:05:23'),(63,'305103',69,1,'2025-07-22 14:24:26'),(64,'305103',68,2,'2025-07-22 14:26:00'),(65,'305103',69,1,'2025-07-22 14:26:04'),(66,'305103',69,1,'2025-07-22 14:29:14'),(67,'305103',69,1,'2025-07-22 16:36:27'),(68,'307327',70,3,'2025-07-23 08:07:51'),(69,'292044',68,2,'2025-07-25 08:51:33'),(70,'292044',69,1,'2025-07-25 08:51:38'),(71,'307327',69,1,'2025-08-08 10:43:20');
/*!40000 ALTER TABLE `recordview_tab` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-27 16:00:19
