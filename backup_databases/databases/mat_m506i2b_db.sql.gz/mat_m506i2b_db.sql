-- MySQL dump 10.13  Distrib 9.1.0, for Win64 (x86_64)
--
-- Host: localhost    Database: mat_m506i2b_db
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `mat_m506i2b_db`
--

/*!40000 DROP DATABASE IF EXISTS `mat_m506i2b_db`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `mat_m506i2b_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `mat_m506i2b_db`;

--
-- Table structure for table `filedata_tab`
--

DROP TABLE IF EXISTS `filedata_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `filedata_tab` (
  `fd_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `fd_ps_id` int NOT NULL COMMENT '配件編號(FK)',
  `fd_name` varchar(255) NOT NULL COMMENT '名稱',
  `fd_description` varchar(255) NOT NULL COMMENT '描述',
  `fd_path` varchar(255) NOT NULL COMMENT '路徑',
  `fd_fulltext` mediumtext COMMENT '全文檢索',
  `fd_sort` tinyint NOT NULL COMMENT '排序',
  `fd_status` tinyint NOT NULL DEFAULT '1' COMMENT '狀態(1:啟用,0:禁用)',
  `fd_createtime` datetime NOT NULL COMMENT '建立時間',
  PRIMARY KEY (`fd_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='檔案資料';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filedata_tab`
--

LOCK TABLES `filedata_tab` WRITE;
/*!40000 ALTER TABLE `filedata_tab` DISABLE KEYS */;
/*!40000 ALTER TABLE `filedata_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `partstock_tab`
--

DROP TABLE IF EXISTS `partstock_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `partstock_tab` (
  `ps_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `ps_mf_id` varchar(10) DEFAULT NULL COMMENT '廠商編號(FK)',
  `ps_un_id` varchar(5) DEFAULT NULL COMMENT '單位編號(FK)',
  `ps_mat_no` varchar(20) NOT NULL DEFAULT '000000000000' COMMENT '材料編號',
  `ps_no` varchar(50) NOT NULL COMMENT '配件編號',
  `ps_name` varchar(100) NOT NULL COMMENT '配件名稱',
  `ps_qty` double NOT NULL COMMENT '存量',
  `ps_qty_general` double NOT NULL COMMENT '一般存量',
  `ps_qty_special` double NOT NULL COMMENT '專案存量',
  `ps_qty_cost` double NOT NULL COMMENT '配件資產存量',
  `ps_location` varchar(50) DEFAULT NULL COMMENT '儲位',
  `ps_qty_safe` int NOT NULL COMMENT '安全存量',
  `ps_size` varchar(25) DEFAULT NULL COMMENT '零件尺寸',
  `ps_number` int DEFAULT NULL COMMENT '號碼',
  `ps_item` varchar(50) DEFAULT NULL COMMENT '件號',
  `ps_note` varchar(255) DEFAULT NULL COMMENT '備註',
  `ps_group` varchar(255) DEFAULT NULL COMMENT '配件群組',
  `ps_datetime_general` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '一般存量更新時間',
  `ps_datetime_special` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '專案存量更新時間',
  `ps_datetime_cost` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '配件資產存量更新時間',
  `ps_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '建立時間',
  PRIMARY KEY (`ps_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='配件庫存';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `partstock_tab`
--

LOCK TABLES `partstock_tab` WRITE;
/*!40000 ALTER TABLE `partstock_tab` DISABLE KEYS */;
/*!40000 ALTER TABLE `partstock_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `parttrans_tab`
--

DROP TABLE IF EXISTS `parttrans_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `parttrans_tab` (
  `pt_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `pt_us_id` varchar(10) NOT NULL COMMENT '部門編號(FK)',
  `pt_ed_id` int NOT NULL COMMENT '設備編號(FK)',
  `pt_ps_id` int NOT NULL COMMENT '配件編號(FK)',
  `pt_ud_id` varchar(20) NOT NULL COMMENT '收發人員編號(FK)',
  `pt_ed_no` varchar(20) NOT NULL COMMENT '設備編號',
  `pt_mat_no` varchar(20) NOT NULL COMMENT '材料編號',
  `pt_ps_no` varchar(50) NOT NULL COMMENT '配件編號',
  `pt_qty_income` double NOT NULL COMMENT '收料',
  `pt_qty_outgo` double NOT NULL COMMENT '發料',
  `pt_qty_total` double NOT NULL COMMENT '存量',
  `pt_qty_general_total` double NOT NULL COMMENT '一般存量',
  `pt_qty_special_total` double NOT NULL COMMENT '專案存量',
  `pt_qty_cost_total` double NOT NULL COMMENT '配件資產存量',
  `pt_datetime` datetime NOT NULL COMMENT '收發時間',
  PRIMARY KEY (`pt_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='配件收發';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parttrans_tab`
--

LOCK TABLES `parttrans_tab` WRITE;
/*!40000 ALTER TABLE `parttrans_tab` DISABLE KEYS */;
/*!40000 ALTER TABLE `parttrans_tab` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-27  8:00:17
