-- MySQL dump 10.13  Distrib 9.1.0, for Win64 (x86_64)
--
-- Host: localhost    Database: labor_mca1250009_db
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `labor_mca1250009_db`
--

/*!40000 DROP DATABASE IF EXISTS `labor_mca1250009_db`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `labor_mca1250009_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `labor_mca1250009_db`;

--
-- Table structure for table `accountdetail_tab`
--

DROP TABLE IF EXISTS `accountdetail_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accountdetail_tab` (
  `ad_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `ad_al_id` int NOT NULL COMMENT '總表編號(FK)',
  `ad_cd_id` int NOT NULL COMMENT '契約編號(FK)',
  `ad_cr_id` int NOT NULL COMMENT '困難乘數編號(FK)',
  `ad_wr1_id` int NOT NULL COMMENT '困難度1編號(FK)',
  `ad_wr2_id` int NOT NULL COMMENT '困難度2編號(FK)',
  `ad_estimated_quantity` double NOT NULL DEFAULT '0' COMMENT '預估數量',
  `ad_billing_quantity` double NOT NULL DEFAULT '0' COMMENT '結算數量',
  `ad_workorder` varchar(50) DEFAULT NULL COMMENT '工作單號',
  `ad_changed_price` varchar(10) NOT NULL DEFAULT '0' COMMENT '更改單價',
  PRIMARY KEY (`ad_id`)
) ENGINE=InnoDB AUTO_INCREMENT=212 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='工作通知/結算書(細表)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accountdetail_tab`
--

LOCK TABLES `accountdetail_tab` WRITE;
/*!40000 ALTER TABLE `accountdetail_tab` DISABLE KEYS */;
INSERT INTO `accountdetail_tab` VALUES (13,5,1,0,0,0,1,1,'','0'),(14,5,2,0,0,0,8,8,'','0'),(15,5,8,0,0,0,16,15,'','0'),(16,5,23,0,0,0,7,7,'','0'),(17,6,1,0,0,0,3,3,'','0'),(18,6,7,0,0,0,2,2,'','0'),(19,6,8,0,0,0,16,14,'','0'),(20,6,52,0,0,0,2,2,'','0'),(21,7,1,0,0,0,1,1,'','0'),(22,7,6,0,0,0,1,1,'','0'),(23,7,8,0,0,0,8,7,'','0'),(24,7,15,0,0,0,1,1,'','0'),(25,8,1,0,0,0,1,1,'','0'),(26,9,2,0,0,0,2,2,'','0'),(27,9,8,0,0,0,8,6,'','0'),(28,9,23,0,0,0,3,3,'','0'),(32,12,1,0,0,0,15,15,'','0'),(33,12,3,0,0,0,9,9,'','0'),(34,12,8,0,0,0,28,23,'','0'),(38,14,1,0,0,0,2,2,'','0'),(39,14,2,0,0,0,3,3,'','0'),(40,14,8,0,0,0,12,9,'','0'),(41,14,23,0,0,0,3,3,'','0'),(42,15,3,0,0,0,1,1,'6004-255-6D30-05','0'),(43,16,1,0,0,0,4,4,'','0'),(44,16,3,0,0,0,5,5,'','0'),(45,16,8,0,0,0,24,21,'','0'),(46,16,36,0,0,0,4,4,'','0'),(47,16,37,0,0,0,4,4,'','0'),(48,16,39,0,0,0,4,4,'','0'),(49,17,1,0,0,0,6,6,'','0'),(50,17,8,0,0,0,16,15,'','0'),(54,19,2,0,0,0,2,2,'','0'),(55,19,8,0,0,0,8,8,'','0'),(56,19,23,0,0,0,4,4,'','0'),(57,20,1,0,0,0,1,1,'','0'),(59,20,9,0,0,0,1,1,'','0'),(60,21,1,0,0,0,1,1,'','0'),(62,21,9,0,0,0,1,1,'','0'),(63,22,1,0,0,0,9,9,'','0'),(64,22,2,0,0,0,1,1,'','0'),(65,22,3,0,0,0,7,7,'','0'),(66,22,8,0,0,0,24,23,'','0'),(67,23,1,0,0,0,5,5,'','0'),(68,23,3,0,0,0,14,14,'','0'),(69,23,6,0,0,0,2,2,'','0'),(70,23,8,0,0,0,16,16,'','0'),(71,23,15,0,0,0,2,2,'','0'),(72,23,35,0,0,0,4,4,'','0'),(73,23,36,0,0,0,6,6,'','0'),(74,23,37,0,0,0,6,6,'','0'),(75,24,1,0,0,0,3,3,'','0'),(76,24,6,0,0,0,3,3,'','0'),(77,24,15,0,0,0,3,3,'','0'),(85,26,2,0,0,0,4,4,'','0'),(87,26,23,0,0,0,4,4,'','0'),(88,27,1,0,0,0,6,6,'','0'),(89,27,8,0,0,0,16,12,'','0'),(90,28,1,0,0,0,3,3,'','0'),(91,28,6,0,0,0,3,3,'','0'),(92,28,8,0,0,0,8,6,'','0'),(93,28,15,0,0,0,3,3,'','0'),(94,29,1,0,0,0,1,1,'','0'),(95,29,8,0,0,0,8,2,'','0'),(96,30,1,0,0,0,3,3,'','0'),(97,30,2,0,0,0,13,13,'','0'),(98,30,3,0,0,0,4,4,'','0'),(99,30,8,0,0,0,32,26,'','0'),(100,30,23,0,0,0,10,10,'','0'),(101,30,36,0,0,0,3,3,'','0'),(102,30,37,0,0,0,3,3,'','0'),(103,31,1,0,0,0,2,2,'','0'),(104,31,8,0,0,0,8,8,'','0'),(105,32,2,0,0,0,1,1,'','0'),(106,32,8,0,0,0,4,3,'','0'),(107,33,2,0,0,0,4,4,'','0'),(108,33,8,0,0,0,8,7,'','0'),(109,34,2,0,0,0,1,1,'','0'),(110,34,6,0,0,0,1,1,'','0'),(111,34,8,0,0,0,8,3,'','0'),(112,34,23,0,0,0,2,2,'','0'),(119,36,1,0,0,0,9,9,'','0'),(120,36,2,0,0,0,14,14,'','0'),(121,36,6,0,0,0,1,1,'','0'),(122,36,8,0,0,0,24,20,'','0'),(123,36,15,0,0,0,1,1,'','0'),(124,36,23,0,0,0,12,12,'','0'),(125,34,28,0,0,0,1,1,'','0'),(126,37,1,0,0,0,8,8,'','0'),(127,37,8,0,0,0,16,12,'','0'),(128,38,1,0,0,0,2,2,'','0'),(129,38,3,0,0,0,8,8,'','0'),(130,38,8,0,0,0,24,17,'','0'),(131,38,36,0,0,0,8,8,'','0'),(132,38,37,0,0,0,8,8,'','0'),(133,38,38,0,0,0,6,6,'','0'),(134,38,39,0,0,0,8,8,'','0'),(135,39,1,0,0,0,15,15,'','0'),(136,39,2,0,0,0,21,21,'','0'),(137,39,6,0,0,0,4,4,'','0'),(138,39,8,0,0,0,32,23,'','0'),(139,39,15,0,0,0,4,4,'','0'),(140,39,23,0,0,0,11,11,'','0'),(141,39,31,0,0,0,1,1,'','0'),(142,40,1,0,0,0,1,1,'','0'),(143,40,7,0,0,0,1,1,'','0'),(144,40,8,0,0,0,8,6,'','0'),(145,40,47,0,0,0,1,1,'','0'),(146,40,50,0,0,0,1,1,'','0'),(147,40,53,0,0,0,1,1,'','0'),(148,41,1,0,0,0,4,4,'','0'),(149,41,2,0,0,0,5,5,'','0'),(150,41,8,0,0,0,8,7,'','0'),(151,42,1,0,0,0,1,1,'','0'),(152,43,2,0,0,0,17,17,'','0'),(153,43,8,0,0,0,16,13,'','0'),(154,44,1,0,0,0,16,16,'','0'),(155,44,3,0,0,0,5,5,'','0'),(156,44,8,0,0,0,16,14,'','0'),(157,45,1,0,0,0,2,2,'','0'),(158,46,1,0,0,0,4,4,'','0'),(159,46,2,0,0,0,3,3,'','0'),(160,46,3,0,0,0,3,3,'','0'),(161,46,8,0,0,0,16,13,'','0'),(162,46,36,0,0,0,3,3,'','0'),(163,46,37,0,0,0,3,3,'','0'),(164,47,36,0,0,0,1,1,'','0'),(165,48,1,0,0,0,12,12,'','0'),(166,48,3,0,0,0,4,4,'','0'),(167,48,6,0,0,0,1,1,'','0'),(168,48,8,0,0,0,24,18,'','0'),(169,48,36,0,0,0,4,4,'','0'),(170,48,37,0,0,0,4,4,'','0'),(171,48,38,0,0,0,3,3,'','0'),(172,48,39,0,0,0,1,1,'','0'),(173,49,1,0,0,0,1,1,'','0'),(174,50,1,0,0,0,1,1,'','0'),(175,50,3,0,0,0,7,7,'','0'),(176,50,6,0,0,0,1,1,'','0'),(177,50,8,0,0,0,8,6,'','0'),(178,51,2,0,0,0,3,3,'','0'),(179,51,8,0,0,0,8,6,'','0'),(180,51,23,0,0,0,1,1,'','0'),(181,52,1,0,0,0,4,4,'','0'),(182,52,2,0,0,0,3,3,'','0'),(183,52,8,0,0,0,8,7,'','0'),(184,53,2,0,0,0,12,12,'','0'),(185,53,8,0,0,0,8,8,'','0'),(186,53,23,0,0,0,14,14,'','0'),(187,54,2,0,0,0,1,1,'','0'),(188,54,8,0,0,0,8,4,'','0'),(189,54,27,0,0,0,1,1,'','0'),(190,55,1,0,0,0,14,14,'','0'),(191,55,2,0,0,0,10,10,'','0'),(192,55,8,0,0,0,32,27,'','0'),(193,55,23,0,0,0,10,10,'','0'),(194,56,1,0,0,0,3,3,'','0'),(195,57,2,0,0,0,4,4,'','0'),(196,57,3,0,0,0,6,6,'','0'),(197,57,23,0,0,0,4,4,'','0'),(198,57,35,0,0,0,1,1,'','0'),(199,58,1,0,0,0,5,5,'','0'),(200,59,1,0,0,0,1,1,'','0'),(201,60,2,0,0,0,1,1,'','0'),(202,60,23,0,0,0,2,2,'','0'),(203,61,1,0,0,0,7,7,'','0'),(204,61,2,0,0,0,10,10,'','0'),(205,61,3,0,0,0,18,18,'','0'),(206,61,8,0,0,0,32,26,'','0'),(207,61,23,0,0,0,10,10,'','0'),(208,61,27,0,0,0,1,1,'','0'),(209,61,39,0,0,0,1,1,'','0'),(210,62,2,0,0,0,6,6,'','0'),(211,63,1,0,0,0,3,3,'','0');
/*!40000 ALTER TABLE `accountdetail_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accountlist_tab`
--

DROP TABLE IF EXISTS `accountlist_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accountlist_tab` (
  `al_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `al_us_id` varchar(15) NOT NULL COMMENT '部門編號(FK)',
  `al_ud_id` varchar(30) NOT NULL COMMENT '使用者編號(FK)',
  `al_item` varchar(10) NOT NULL DEFAULT '' COMMENT '工作通知次數',
  `al_applyorder` varchar(50) NOT NULL DEFAULT '' COMMENT '申請單號',
  `al_workorder` varchar(50) NOT NULL COMMENT '工作單號',
  `al_construction` varchar(255) NOT NULL COMMENT '施工圖說',
  `al_content` varchar(255) NOT NULL COMMENT '工作範圍說明',
  `al_multiplier` double NOT NULL DEFAULT '1' COMMENT '單價乘數',
  `al_deadline` int NOT NULL COMMENT '期限',
  `al_begindate` date NOT NULL COMMENT '開工日期',
  `al_enddate` date NOT NULL COMMENT '完工日期',
  `al_billed` tinyint NOT NULL DEFAULT '0' COMMENT '是否已請款(0:未請款,1:已請款)',
  `al_installment` tinyint NOT NULL DEFAULT '0' COMMENT '第幾期',
  `al_datetime` datetime NOT NULL COMMENT '建立時間',
  `al_updatedatetime` datetime NOT NULL COMMENT '更新時間',
  PRIMARY KEY (`al_id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='工作通知/結算書(總表)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accountlist_tab`
--

LOCK TABLES `accountlist_tab` WRITE;
/*!40000 ALTER TABLE `accountlist_tab` DISABLE KEYS */;
INSERT INTO `accountlist_tab` VALUES (5,'M506A30','242578','1','','5401-255-6A30-05','','C區泵房GCB及GCS故障檢修及保養工作',1,2,'2024-05-08','2024-05-09',1,1,'2024-07-02 09:17:07','2024-10-15 14:54:19'),(6,'M506C50','242578','2','','FM006C50','','烯烴轉化工場大修GCB故障檢修及保養工作',1,2,'2024-05-16','2024-05-17',1,1,'2024-07-02 09:44:33','2024-09-30 15:12:32'),(7,'M506B30','242578','3','','6004-255-6B35-05','','第二變電所GCB故障檢修及保養工作',1,1,'2024-05-23','2024-05-23',1,1,'2024-07-02 09:53:19','2024-09-30 15:13:05'),(8,'M506B30','242578','4','','6004-255-6B36-05','','第三變電所HA-12A  GCB維護保養(含潤滑)工作',1,1,'2024-05-23','2024-05-23',1,1,'2024-07-02 10:00:47','2024-09-30 15:13:40'),(9,'M506B10','242578','5','','FM006B17','','B-408鍋爐大修GCS故障檢修及保養工作',1,1,'2024-05-30','2024-05-30',1,1,'2024-07-02 10:04:27','2024-09-30 15:14:04'),(12,'M506F50','242578','7','','FM006F50','','第十一柴油加氫脫硫工場大修GCB維護保養(含潤滑)工作',1,26,'2024-07-16','2024-08-10',1,1,'2024-08-07 10:18:58','2024-09-30 15:14:36'),(14,'M506B10','242578','6','','6004-255-6B1B-05','','24水塔GCB及GCS故障檢修保養工作',1,20,'2024-07-03','2024-07-22',1,1,'2024-08-27 15:17:04','2024-09-30 15:14:23'),(15,'M506D30','242578','8','','6004-255-6D31-05','','第二氫氣工場16水塔ACB維護保養工作',1,1,'2024-08-26','2024-08-26',1,1,'2024-09-04 15:06:20','2024-09-30 15:15:15'),(16,'M506E52','242578','9','','FM006E52','','第四硫磺工場大修GCB及ACB故障檢修及保養工作',1,3,'2024-09-03','2024-09-05',1,2,'2024-10-11 10:31:39','2024-12-17 09:48:32'),(17,'M506G10','242578','10','','FM006G10','','第五媒組工場大修GCB保養工作',1,2,'2024-09-09','2024-09-10',1,2,'2024-10-11 10:34:37','2024-12-17 09:48:43'),(19,'M506N10','242578','12','','5401-255-6N12-05','','B區泵房GCS故障檢修及保養工作',1,1,'2024-10-08','2024-10-08',1,2,'2024-10-11 10:37:50','2024-12-17 09:49:06'),(20,'M506E70','242578','14','','6004-255-6E70-05','','烷化工場VCB故障檢修及保養工作',1,1,'2024-10-08','2024-10-08',1,2,'2024-10-11 10:42:08','2024-12-17 09:49:23'),(21,'M506F40','242578','13','','6004-255-6F40-05','','第十柴油加氫脫硫工場VCB故障檢修及保養工作',1,1,'2024-10-08','2024-10-08',1,2,'2024-10-11 10:44:10','2024-12-17 09:49:14'),(22,'M506F70','242578','11','','FM006F70','','第十二煤油加氫脫硫工場大修高低壓開關維護保養(含潤滑)工作',1,27,'2024-09-23','2024-10-19',1,2,'2024-11-07 09:53:20','2024-12-17 09:48:54'),(23,'M506D30','242578','15','','FM006D32','','21水塔大修GCB及ACB故障檢修及保養工作',1,2,'2024-11-18','2024-11-19',1,3,'2024-12-17 14:21:33','2025-02-08 10:41:19'),(24,'M506D30','242578','16','','6004-255-6D30-05','','第二氫氣工場C-2930B變壓器及馬達GCB故障檢修及保養工作',1,2,'2024-11-18','2024-11-19',1,3,'2024-12-17 14:30:42','2025-02-08 10:41:36'),(26,'M506N10','242578','18','','5401-255-6N12-05','','B區泵房GCS故障檢修及保養工作',1,1,'2024-11-21','2024-11-21',1,3,'2024-12-17 14:38:45','2025-02-08 10:41:58'),(27,'M506D50','242578','20','','FM006D50','','重油裂解工場大修高壓開關維護保養(含潤滑)工作',1,2,'2024-12-05','2024-12-06',1,3,'2024-12-17 14:44:06','2025-02-08 10:42:19'),(28,'M506A30','242578','21','','6004-255-6A31-05','','二橋油庫GCB故障檢修及保養工作',1,1,'2024-12-13','2024-12-13',1,3,'2024-12-17 14:47:53','2025-02-08 10:42:30'),(29,'M506N10','242578','19','','5401-255-6N12-05','','B區泵房GCB維護保養(含潤滑)工作',1,1,'2024-12-04','2024-12-04',1,3,'2024-12-19 09:34:44','2025-02-08 10:42:10'),(30,'M506C20','242578','17','','FM006C20','','第十蒸餾工場停爐高低壓開關故障檢修及保養工作',1,11,'2024-11-20','2024-11-30',1,3,'2024-12-21 14:17:55','2025-02-08 10:41:47'),(31,'M506D50','242578','22','','FM006D50','','重油裂解工場大修GCB維護保養(含潤滑)工作',1,1,'2025-01-05','2025-01-05',1,3,'2024-12-17 14:44:06','2025-02-08 10:42:38'),(32,'M506B10','242578','23','','6004-255-6B12-05','','第一空氣中心GCS維護保養(含潤滑)工作',1,1,'2025-02-12','2025-02-12',1,4,'2025-02-24 10:42:44','2025-06-04 09:35:27'),(33,'M506A30','242578','24','','5401-255-6A33-05','','高松油庫消防泵浦VCS維護保養(含潤滑)工作',1,1,'2025-03-19','2025-03-19',1,4,'2025-03-31 10:20:35','2025-06-04 09:35:40'),(34,'M506G20','242578','25','','6004-255-6G20-05','','第六媒組工場GCS故障檢修及保養工作',1,1,'2025-03-20','2025-03-20',1,4,'2025-03-31 10:24:59','2025-06-04 09:35:53'),(36,'M506A20','242578','26','','5401-255-6A23-05','','D2區GCB及GCS故障檢修及保養工作',1,8,'2025-03-24','2025-03-31',1,4,'2025-04-07 13:04:39','2025-06-04 09:36:04'),(37,'M506C70','242578','27','','FM006C70','','第九柴油加氫脫硫工場大修GCB維護保養(含潤滑)工作',1,4,'2025-04-07','2025-04-10',1,4,'2025-04-21 14:09:56','2025-06-04 09:36:14'),(38,'M506C80','242578','28','','FM006C80','','正烷烴工場大修GCB及ACB故障檢修及保養工作',1,7,'2025-04-11','2025-04-17',1,4,'2025-04-21 14:12:08','2025-06-04 09:36:27'),(39,'M506A20','242578','29','','5401-255-6A22-05','','D1區GCB及GCS故障檢修及保養工作',1,8,'2025-04-14','2025-04-21',1,4,'2025-04-21 14:14:54','2025-06-04 09:36:41'),(40,'M506G10','242578','30','','6004-255-6G10-05','','第五媒組工場高低壓開關故障檢修及保養工作',1,1,'2025-05-03','2025-05-03',0,0,'2025-05-19 09:36:12','2025-05-19 09:41:24'),(41,'M506B30','242578','31','','6004-255-6B36-05','','第三變電所VCB及VCS維護保養(含潤滑)工作',1,1,'2025-05-17','2025-05-17',0,0,'2025-05-29 11:01:18','2025-05-29 11:03:36'),(42,'M506E40','242578','32','','6004-255-6E40-05','','第三重油脫硫工場工場GCB維護保養工作',1,1,'2025-05-17','2025-05-17',0,0,'2025-05-29 11:04:52','2025-05-29 11:06:35'),(43,'M506G20','242578','33','','FM006G20','','第六媒組工場大修GCS維護保養(含潤滑)工作',1,2,'2025-06-19','2025-06-20',0,0,'2025-07-18 15:05:32','2025-07-18 15:36:45'),(44,'M506G20','242578','34','','FM006G20','','第六媒組工場大修GCB及ACB維護保養(含潤滑)工作',1,2,'2025-07-01','2025-07-02',0,0,'2025-07-18 15:09:54','2025-07-18 15:37:50'),(45,'M506B30','242578','35','','6004-255-6B36-05','','第三變電所VCB維護保養(含潤滑)工作',1,2,'2025-07-01','2025-07-02',0,0,'2025-07-18 15:11:57','2025-07-18 15:17:12'),(46,'M506D20','242578','36','','FM006D20','','第六硫磺工場停爐高低開關故障檢修及保養工作',1,3,'2025-07-08','2025-07-10',0,0,'2025-07-18 15:17:20','2025-07-18 15:20:16'),(47,'M506A20','242578','37','','5401-312-6A35-05','','高松二區MCC開關故障檢修',1,1,'2025-07-08','2025-07-08',0,0,'2025-07-18 15:21:12','2025-07-18 15:22:30'),(48,'M506D10','242578','38','','FM006D10','','第一重油脫硫工場停爐GCB及ACB故障檢修及維護保養(含潤滑)工作',1,7,'2025-07-09','2025-07-15',0,0,'2025-07-18 15:24:43','2025-07-18 15:27:16'),(49,'M506E60','242578','39','','6004-255-6E60-05','','第二汽油加氫脫硫工場GCB維護保養(含潤滑)工作',1,1,'2025-07-10','2025-07-10',0,0,'2025-07-18 15:29:00','2025-07-18 15:30:13'),(50,'M506D30','242578','40','','FM006D31','','#16水塔大修GCB及ACB維護保養(含潤滑)工作',1,1,'2025-07-11','2025-07-11',0,0,'2025-07-18 15:31:44','2025-07-18 15:33:21'),(51,'M506P20','242578','41','','6004-255-6P20-05','','烏材林區儲運課第七變電站GCS故障檢修及保養工作',1,1,'2025-07-17','2025-07-17',0,0,'2025-07-18 15:34:26','2025-07-18 15:35:38'),(52,'M506A20','242578','42','','5401-255-6A35-05','','高松二區高壓開關維護保養(含潤滑)工作',1,1,'2025-07-23','2025-07-23',0,0,'2025-08-12 09:44:45','2025-08-12 12:40:56'),(53,'M506N10','242578','43','','6004-255-6N10-05','','A 區泵房GCS故障檢修及保養工作',1,1,'2025-07-24','2025-07-24',0,0,'2025-08-12 12:41:32','2025-08-12 12:45:01'),(54,'M506G40','242578','44','','6004-255-6G40-05','','重油媒裂工場VCS故障檢修及保養工作',1,1,'2025-07-31','2025-07-31',0,0,'2025-08-12 12:45:11','2025-08-12 12:46:47'),(55,'M506E40','242578','45','','FM006E40','','第三重油加氫脫硫工場停爐GCB及GCS故障檢修及保養工作',1,8,'2025-08-04','2025-08-11',0,0,'2025-08-12 12:46:57','2025-08-14 09:12:11'),(56,'M506B30','242578','46','','6004-255-6B36-05','','第三變電所VCB維護保養(含潤滑)工作',1,3,'2025-08-04','2025-08-06',0,0,'2025-08-12 12:49:47','2025-08-14 09:12:36'),(57,'M506E50','242578','47','','FM006E50','','第八硫磺工場大修GCS及ACB故障檢修及保養工作',1,8,'2025-08-04','2025-08-11',0,0,'2025-08-12 12:51:21','2025-08-12 12:51:21'),(58,'M506E52','242578','48','','FM006E52','','第四硫磺工場大修GCB維護保養(含潤滑)工作',1,2,'2025-08-04','2025-08-05',0,0,'2025-08-12 12:53:13','2025-08-14 09:16:46'),(59,'M506F60','242578','49','','6004-255-6F60-05','','第十二蒸餾工場GCB維護保養(含潤滑)工作',1,1,'2025-08-05','2025-08-05',0,0,'2025-08-12 12:54:38','2025-08-26 14:40:27'),(60,'M506A30','242578','50','','5401-255-6A33-05','','高松油庫GCS故障檢修及保養工作',1,1,'2025-08-06','2025-08-06',0,0,'2025-08-12 13:02:04','2025-08-12 13:02:04'),(61,'M506B20','242578','51','','6004-255-6B23-05','','原水站高低開關故障檢修及保養工作',1,12,'2025-08-18','2025-08-29',0,0,'2025-09-03 09:37:49','2025-09-03 09:43:14'),(62,'M506G30','242578','52','','6004-255-6G30-05','','油氣純化工場GCS維護保養(含潤滑)工作',1,12,'2025-08-18','2025-08-29',0,0,'2025-09-03 09:43:22','2025-09-03 09:45:37'),(63,'M506B30','242578','53','','6004-255-6B36-05','','第三變電所GCB維護保養(含潤滑)工作',1,2,'2025-08-28','2025-08-29',0,0,'2025-09-03 09:45:44','2025-09-03 09:58:16');
/*!40000 ALTER TABLE `accountlist_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accountprofitfee_tab`
--

DROP TABLE IF EXISTS `accountprofitfee_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accountprofitfee_tab` (
  `ap_al_id` int NOT NULL COMMENT '工作通知/結算書(總表)編號(PK)',
  `ap_pf_id` int NOT NULL COMMENT '利潤及管理費編號(PK)',
  `ap_estimated_quantity` double NOT NULL DEFAULT '0' COMMENT '預估數量',
  `ap_billing_quantity` double NOT NULL DEFAULT '0' COMMENT '結算數量',
  `ap_workorder` varchar(50) DEFAULT NULL COMMENT '工作單號',
  `ap_status` tinyint NOT NULL DEFAULT '0' COMMENT '0:不列入計算,1:列入計算',
  PRIMARY KEY (`ap_al_id`,`ap_pf_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='利潤及管理費的刪除表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accountprofitfee_tab`
--

LOCK TABLES `accountprofitfee_tab` WRITE;
/*!40000 ALTER TABLE `accountprofitfee_tab` DISABLE KEYS */;
/*!40000 ALTER TABLE `accountprofitfee_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contractdata_tab`
--

DROP TABLE IF EXISTS `contractdata_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contractdata_tab` (
  `cd_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `cd_ct_id` int NOT NULL COMMENT '困難度換算表編號(FK)',
  `cd_wt_id` int NOT NULL COMMENT '換算表編號(FK)',
  `cd_item` varchar(10) NOT NULL COMMENT '項次',
  `cd_name` varchar(255) NOT NULL COMMENT '項目及說明',
  `cd_text` varchar(100) DEFAULT NULL COMMENT '結算書文字',
  `cd_unit` varchar(10) NOT NULL COMMENT '單位',
  `cd_quantity` int NOT NULL DEFAULT '1' COMMENT '數量',
  `cd_price` varchar(10) NOT NULL DEFAULT '0' COMMENT '單價',
  `cd_sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`cd_id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='契約';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contractdata_tab`
--

LOCK TABLES `contractdata_tab` WRITE;
/*!40000 ALTER TABLE `contractdata_tab` DISABLE KEYS */;
INSERT INTO `contractdata_tab` VALUES (1,0,0,'1','高壓斷路器維護保養(GCB、VCB)','','ST',200,'12083.964',1),(2,0,0,'2','高壓接觸器維護保養(GCS、VCS)','','ST',120,'9827.176',2),(3,0,0,'3','低壓斷路器維護保養(ACB)','','ST',140,'9827.176',3),(4,0,0,'4','電氣檢修工','','小時',800,'224.314',4),(5,0,0,'5','GCB絕緣套管更換','','ST',20,'2746.355',5),(6,0,0,'6','控制線組更換','','ST',10,'4377.111',6),(7,0,0,'7','ACB轉接套件更換','','SET',10,'29304.125',7),(8,0,0,'8','職業安全衛生管理人員出勤費用','','小時',800,'208.109',8),(9,0,0,'9','儲能馬達','','PC',1,'23326.964',9),(10,0,0,'10','投入線圈','','PC',1,'8184.481',10),(11,0,0,'11','跳脫線圈','','PC',1,'8184.481',11),(12,0,0,'12','輔助接點組','','PC',1,'8136.718',12),(13,0,0,'13','微動開關','','PC',1,'8184.481',13),(14,0,0,'14','ON/OFF手動操作連動機構組','','PC',1,'17001.817',14),(15,0,0,'15','控制線組','','PC',1,'77773.035',15),(16,0,0,'16','斷路器引出入機構','','PC',1,'18046.626',16),(17,0,0,'17','消弧室1250A以下','','PC',1,'18046.626',17),(18,0,0,'18','消弧室1600A以上','','PC',1,'40291.253',18),(19,0,0,'19','斷路器框架1250A以下','','PC',1,'18046.626',19),(20,0,0,'20','斷路器框架1600A以上','','PC',1,'40424.306',20),(21,0,0,'21','絕緣套管1250A以下','','PC',1,'11651.541',21),(22,0,0,'22','絕緣套管1600A以上','','PC',1,'20541.374',22),(23,0,0,'23','控制電路板','','PC',1,'11515.076',23),(24,0,0,'24','投入線圈','','PC',1,'14439.689',24),(25,0,0,'25','跳脫線圈','','PC',1,'9016.063',25),(26,0,0,'26','輔助接點組','','PC',1,'4857.296',26),(27,0,0,'27','微動開關','','PC',1,'1640.99',27),(28,0,0,'28','控制線組','','PC',1,'63887.734',28),(29,0,0,'29','消弧室FOR GCS三相共管','','PC',1,'50561.087',29),(30,0,0,'30','消弧室FOR VCS單相單管','','PC',1,'15179.158',30),(31,0,0,'31','接觸器框架FOR GCS','','PC',1,'19882.931',31),(32,0,0,'32','接觸器框架FOR VCS','','PC',1,'18792.918',32),(33,0,0,'33','絕緣套管FOR GCS','','PC',1,'12114.669',33),(34,0,0,'34','絕緣套管FOR VCS','','PC',1,'12114.669',34),(35,0,0,'35','儲能馬達','','PC',1,'18937.912',35),(36,0,0,'36','投入線圈','','PC',1,'12406.362',36),(37,0,0,'37','跳脫線圈','','PC',1,'12406.362',37),(38,0,0,'38','低電壓跳脫線圈','','PC',1,'15746.34',38),(39,0,0,'39','NW OCR控制單元','','PC',1,'14017.501',39),(40,0,0,'40','輔助接點組','','PC',1,'4358.347',40),(41,0,0,'41','微動開關','','PC',1,'1647.813',41),(42,0,0,'42','ON/OFF手動操作連動機構組','','PC',1,'17116.106',42),(43,0,0,'43','控制線組','','PC',1,'11760.713',43),(44,0,0,'44','斷路器引出入機構','','PC',1,'14232.433',44),(45,0,0,'45','斷路器框架 3P 1600A以下','','PC',1,'15322.446',45),(46,0,0,'46','斷路器框架 3P 2000A~2500A','','PC',1,'19894.019',46),(47,0,0,'47','斷路器框架 3P 3200A~4000A','','PC',1,'24923.603',47),(48,0,0,'48','斷路器框架ACB本體 3P 1600A以下','','PC',1,'101407.044',48),(49,0,0,'49','斷路器框架ACB本體 3P 2000A~2500A','','PC',1,'127685.914',49),(50,0,0,'50','斷路器框架ACB本體 3P 3200A~4000A','','PC',1,'151225.251',50),(51,0,0,'51','ACB轉接銅排(M->NW type)水平3P 800-1600A','','SET',1,'26106.582',51),(52,0,0,'52','ACB轉接銅排(M->NW type)水平3P 2000-2500A','','SET',1,'27942.888',52),(53,0,0,'53','ACB轉接銅排(M->NW type)水平3P 3200A','','SET',1,'32391.643',53),(54,0,0,'54','ACB轉接銅排(M->NW type)水平3P 4000A','','SET',1,'34806.218',54),(55,0,0,'55','ACB轉接銅排(M->NW type)垂直3P 800-1600A','','SET',1,'28010.267',55),(56,0,0,'56','ACB轉接銅排(M->NW type)垂直3P 2000-2500A','','SET',1,'29462.765',56),(57,0,0,'57','ACB轉接銅排(M->NW type)垂直3P 3200A','','SET',1,'35887.702',57),(58,0,0,'58','ACB轉接銅排(M->NW type)垂直3P 4000A','','SET',1,'47327.722',58);
/*!40000 ALTER TABLE `contractdata_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contractratio_tab`
--

DROP TABLE IF EXISTS `contractratio_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contractratio_tab` (
  `cr_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `cr_ct_id` int NOT NULL COMMENT '表格編號(FK)',
  `cr_item` int NOT NULL COMMENT '項次',
  `cr_multiplier` double NOT NULL COMMENT '乘數',
  `cr_content` varchar(255) NOT NULL COMMENT '內容',
  PRIMARY KEY (`cr_id`),
  UNIQUE KEY `cr_ct_id` (`cr_ct_id`,`cr_item`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='契約困難度換算表(乘數)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contractratio_tab`
--

LOCK TABLES `contractratio_tab` WRITE;
/*!40000 ALTER TABLE `contractratio_tab` DISABLE KEYS */;
/*!40000 ALTER TABLE `contractratio_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contracttable_tab`
--

DROP TABLE IF EXISTS `contracttable_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contracttable_tab` (
  `ct_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `ct_name` varchar(255) NOT NULL COMMENT '表格名稱',
  `ct_sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`ct_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='契約困難度換算表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contracttable_tab`
--

LOCK TABLES `contracttable_tab` WRITE;
/*!40000 ALTER TABLE `contracttable_tab` DISABLE KEYS */;
/*!40000 ALTER TABLE `contracttable_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profitfee_tab`
--

DROP TABLE IF EXISTS `profitfee_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `profitfee_tab` (
  `pf_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `pf_from_cd_id` int NOT NULL DEFAULT '0' COMMENT '從契約編號(FK)',
  `pf_to_cd_id` int NOT NULL DEFAULT '0' COMMENT '到契約編號(FK)',
  `pf_excluded_cd_ids` varchar(100) DEFAULT NULL COMMENT '排除契約編號(FK)',
  `pf_tax` enum('G','S','P','F','T') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'G' COMMENT '費用類別(G:一般,S:工安環保費,P:利潤管理費,F:固定單價,T:營業稅)',
  `pf_item` varchar(50) NOT NULL COMMENT '項次',
  `pf_name` varchar(255) NOT NULL COMMENT '項目及說明',
  `pf_unit` varchar(50) NOT NULL COMMENT '單位',
  `pf_quantity` int NOT NULL DEFAULT '1' COMMENT '數量',
  `pf_price` varchar(10) NOT NULL DEFAULT '0' COMMENT '金額',
  `pf_percent` double NOT NULL COMMENT '百分比',
  `pf_sort` tinyint NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`pf_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='附加費用';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profitfee_tab`
--

LOCK TABLES `profitfee_tab` WRITE;
/*!40000 ALTER TABLE `profitfee_tab` DISABLE KEYS */;
INSERT INTO `profitfee_tab` VALUES (1,1,8,NULL,'G','一','工資部份(1~8項和)','式',1,'5709536',0,1),(2,9,58,NULL,'G','二','材料部份(9~58項和)','式',1,'1376867',0,2),(3,1,8,NULL,'P','三','利潤及管理費(1~8項和之10%)利潤管理費','式',1,'570954',10,3),(4,9,58,NULL,'P','四','利潤管理費(9~58項和之3%)','式',1,'41306',3,4),(5,1,7,NULL,'S','五','工安衛生環保管理及措施費(第1~7項和之2%)','式',1,'110861',2,5),(6,0,0,NULL,'T','六','營業稅(一~五項和之5%)','式',1,'390476',5,6);
/*!40000 ALTER TABLE `profitfee_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `requestpayment_tab`
--

DROP TABLE IF EXISTS `requestpayment_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `requestpayment_tab` (
  `rp_installment` tinyint NOT NULL COMMENT '請款期數(PK)',
  `rp_date` date DEFAULT NULL COMMENT '請款日期',
  PRIMARY KEY (`rp_installment`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='請款歸檔';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `requestpayment_tab`
--

LOCK TABLES `requestpayment_tab` WRITE;
/*!40000 ALTER TABLE `requestpayment_tab` DISABLE KEYS */;
INSERT INTO `requestpayment_tab` VALUES (1,'2024-10-08'),(2,'2024-12-18'),(3,'2025-02-10'),(4,'2025-06-11');
/*!40000 ALTER TABLE `requestpayment_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workratio1_tab`
--

DROP TABLE IF EXISTS `workratio1_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workratio1_tab` (
  `wr_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `wr_wt_id` int NOT NULL COMMENT '表格編號(FK)',
  `wr_item` int NOT NULL COMMENT '項次',
  `wr_multiplier` double NOT NULL COMMENT '乘數',
  `wr_content` varchar(255) NOT NULL COMMENT '內容',
  PRIMARY KEY (`wr_id`),
  UNIQUE KEY `wr_wt_id` (`wr_wt_id`,`wr_item`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='工作單價比例換算(困難度1)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workratio1_tab`
--

LOCK TABLES `workratio1_tab` WRITE;
/*!40000 ALTER TABLE `workratio1_tab` DISABLE KEYS */;
/*!40000 ALTER TABLE `workratio1_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workratio2_tab`
--

DROP TABLE IF EXISTS `workratio2_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workratio2_tab` (
  `wr_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `wr_wt_id` int NOT NULL COMMENT '表格編號(FK)',
  `wr_item` int NOT NULL COMMENT '項次',
  `wr_multiplier` double NOT NULL COMMENT '乘數',
  `wr_content` varchar(255) NOT NULL COMMENT '內容',
  PRIMARY KEY (`wr_id`),
  UNIQUE KEY `wr_wt_id` (`wr_wt_id`,`wr_item`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='工作單價比例換算(困難度2)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workratio2_tab`
--

LOCK TABLES `workratio2_tab` WRITE;
/*!40000 ALTER TABLE `workratio2_tab` DISABLE KEYS */;
/*!40000 ALTER TABLE `workratio2_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `worktable_tab`
--

DROP TABLE IF EXISTS `worktable_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `worktable_tab` (
  `wt_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `wt_item` varchar(255) NOT NULL COMMENT '表格編號',
  `wt_name` varchar(255) NOT NULL COMMENT '表格名稱',
  `wt_sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`wt_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='工作單價比例換算表(查表)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `worktable_tab`
--

LOCK TABLES `worktable_tab` WRITE;
/*!40000 ALTER TABLE `worktable_tab` DISABLE KEYS */;
/*!40000 ALTER TABLE `worktable_tab` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-28  0:00:15
