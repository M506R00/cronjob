-- MySQL dump 10.13  Distrib 9.1.0, for Win64 (x86_64)
--
-- Host: localhost    Database: labor_mhb1250012_db
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `labor_mhb1250012_db`
--

/*!40000 DROP DATABASE IF EXISTS `labor_mhb1250012_db`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `labor_mhb1250012_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `labor_mhb1250012_db`;

--
-- Table structure for table `accountdetail_tab`
--

DROP TABLE IF EXISTS `accountdetail_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accountdetail_tab` (
  `ad_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `ad_al_id` int NOT NULL COMMENT '總表編號(FK)',
  `ad_cd_id` int NOT NULL COMMENT '契約編號(FK)',
  `ad_cr_id` int NOT NULL COMMENT '困難乘數編號(FK)',
  `ad_wr1_id` int NOT NULL COMMENT '困難度1編號(FK)',
  `ad_wr2_id` int NOT NULL COMMENT '困難度2編號(FK)',
  `ad_estimated_quantity` double NOT NULL DEFAULT '0' COMMENT '預估數量',
  `ad_billing_quantity` double NOT NULL DEFAULT '0' COMMENT '結算數量',
  `ad_workorder` varchar(50) DEFAULT NULL COMMENT '工作單號',
  `ad_changed_price` varchar(10) NOT NULL DEFAULT '0' COMMENT '更改單價',
  PRIMARY KEY (`ad_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='工作通知/結算書(細表)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accountdetail_tab`
--

LOCK TABLES `accountdetail_tab` WRITE;
/*!40000 ALTER TABLE `accountdetail_tab` DISABLE KEYS */;
/*!40000 ALTER TABLE `accountdetail_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accountlist_tab`
--

DROP TABLE IF EXISTS `accountlist_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accountlist_tab` (
  `al_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `al_us_id` varchar(15) NOT NULL COMMENT '部門編號(FK)',
  `al_ud_id` varchar(30) NOT NULL COMMENT '使用者編號(FK)',
  `al_item` varchar(10) NOT NULL DEFAULT '' COMMENT '工作通知次數',
  `al_applyorder` varchar(50) NOT NULL DEFAULT '' COMMENT '申請單號',
  `al_workorder` varchar(50) NOT NULL COMMENT '工作單號',
  `al_construction` varchar(255) NOT NULL COMMENT '施工圖說',
  `al_content` varchar(255) NOT NULL COMMENT '工作範圍說明',
  `al_multiplier` double NOT NULL DEFAULT '1' COMMENT '單價乘數',
  `al_deadline` int NOT NULL COMMENT '期限',
  `al_begindate` date NOT NULL COMMENT '開工日期',
  `al_enddate` date NOT NULL COMMENT '完工日期',
  `al_billed` tinyint NOT NULL DEFAULT '0' COMMENT '是否已請款(0:未請款,1:已請款)',
  `al_installment` tinyint NOT NULL DEFAULT '0' COMMENT '第幾期',
  `al_datetime` datetime NOT NULL COMMENT '建立時間',
  `al_updatedatetime` datetime NOT NULL COMMENT '更新時間',
  PRIMARY KEY (`al_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='工作通知/結算書(總表)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accountlist_tab`
--

LOCK TABLES `accountlist_tab` WRITE;
/*!40000 ALTER TABLE `accountlist_tab` DISABLE KEYS */;
/*!40000 ALTER TABLE `accountlist_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accountprofitfee_tab`
--

DROP TABLE IF EXISTS `accountprofitfee_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accountprofitfee_tab` (
  `ap_al_id` int NOT NULL COMMENT '工作通知/結算書(總表)編號(PK)',
  `ap_pf_id` int NOT NULL COMMENT '利潤及管理費編號(PK)',
  `ap_estimated_quantity` double NOT NULL DEFAULT '0' COMMENT '預估數量',
  `ap_billing_quantity` double NOT NULL DEFAULT '0' COMMENT '結算數量',
  `ap_workorder` varchar(50) DEFAULT NULL COMMENT '工作單號',
  `ap_status` tinyint NOT NULL DEFAULT '0' COMMENT '0:不列入計算,1:列入計算',
  PRIMARY KEY (`ap_al_id`,`ap_pf_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='利潤及管理費的刪除表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accountprofitfee_tab`
--

LOCK TABLES `accountprofitfee_tab` WRITE;
/*!40000 ALTER TABLE `accountprofitfee_tab` DISABLE KEYS */;
/*!40000 ALTER TABLE `accountprofitfee_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contractdata_tab`
--

DROP TABLE IF EXISTS `contractdata_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contractdata_tab` (
  `cd_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `cd_ct_id` int NOT NULL COMMENT '困難度換算表編號(FK)',
  `cd_wt_id` int NOT NULL COMMENT '換算表編號(FK)',
  `cd_item` varchar(10) NOT NULL COMMENT '項次',
  `cd_name` varchar(255) NOT NULL COMMENT '項目及說明',
  `cd_text` varchar(100) DEFAULT NULL COMMENT '結算書文字',
  `cd_unit` varchar(10) NOT NULL COMMENT '單位',
  `cd_quantity` int NOT NULL DEFAULT '1' COMMENT '數量',
  `cd_price` varchar(10) NOT NULL DEFAULT '0' COMMENT '單價',
  `cd_sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`cd_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='契約';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contractdata_tab`
--

LOCK TABLES `contractdata_tab` WRITE;
/*!40000 ALTER TABLE `contractdata_tab` DISABLE KEYS */;
/*!40000 ALTER TABLE `contractdata_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contractratio_tab`
--

DROP TABLE IF EXISTS `contractratio_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contractratio_tab` (
  `cr_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `cr_ct_id` int NOT NULL COMMENT '表格編號(FK)',
  `cr_item` int NOT NULL COMMENT '項次',
  `cr_multiplier` double NOT NULL COMMENT '乘數',
  `cr_content` varchar(255) NOT NULL COMMENT '內容',
  PRIMARY KEY (`cr_id`),
  UNIQUE KEY `cr_ct_id` (`cr_ct_id`,`cr_item`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='契約困難度換算表(乘數)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contractratio_tab`
--

LOCK TABLES `contractratio_tab` WRITE;
/*!40000 ALTER TABLE `contractratio_tab` DISABLE KEYS */;
/*!40000 ALTER TABLE `contractratio_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contracttable_tab`
--

DROP TABLE IF EXISTS `contracttable_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contracttable_tab` (
  `ct_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `ct_name` varchar(255) NOT NULL COMMENT '表格名稱',
  `ct_sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`ct_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='契約困難度換算表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contracttable_tab`
--

LOCK TABLES `contracttable_tab` WRITE;
/*!40000 ALTER TABLE `contracttable_tab` DISABLE KEYS */;
/*!40000 ALTER TABLE `contracttable_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profitfee_tab`
--

DROP TABLE IF EXISTS `profitfee_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `profitfee_tab` (
  `pf_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `pf_from_cd_id` int NOT NULL DEFAULT '0' COMMENT '從契約編號(FK)',
  `pf_to_cd_id` int NOT NULL DEFAULT '0' COMMENT '到契約編號(FK)',
  `pf_excluded_cd_ids` varchar(100) DEFAULT NULL COMMENT '排除契約編號(FK)',
  `pf_tax` enum('G','S','P','F','T') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'G' COMMENT '費用類別(G:一般,S:工安環保費,P:利潤管理費,F:固定單價,T:營業稅)',
  `pf_item` varchar(50) NOT NULL COMMENT '項次',
  `pf_name` varchar(255) NOT NULL COMMENT '項目及說明',
  `pf_unit` varchar(50) NOT NULL COMMENT '單位',
  `pf_quantity` int NOT NULL DEFAULT '1' COMMENT '數量',
  `pf_price` varchar(10) NOT NULL DEFAULT '0' COMMENT '金額',
  `pf_percent` double NOT NULL COMMENT '百分比',
  `pf_sort` tinyint NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`pf_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='附加費用';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profitfee_tab`
--

LOCK TABLES `profitfee_tab` WRITE;
/*!40000 ALTER TABLE `profitfee_tab` DISABLE KEYS */;
/*!40000 ALTER TABLE `profitfee_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `requestpayment_tab`
--

DROP TABLE IF EXISTS `requestpayment_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `requestpayment_tab` (
  `rp_installment` tinyint NOT NULL COMMENT '請款期數(PK)',
  `rp_date` date DEFAULT NULL COMMENT '請款日期',
  PRIMARY KEY (`rp_installment`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='請款歸檔';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `requestpayment_tab`
--

LOCK TABLES `requestpayment_tab` WRITE;
/*!40000 ALTER TABLE `requestpayment_tab` DISABLE KEYS */;
/*!40000 ALTER TABLE `requestpayment_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workratio1_tab`
--

DROP TABLE IF EXISTS `workratio1_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workratio1_tab` (
  `wr_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `wr_wt_id` int NOT NULL COMMENT '表格編號(FK)',
  `wr_item` int NOT NULL COMMENT '項次',
  `wr_multiplier` double NOT NULL COMMENT '乘數',
  `wr_content` varchar(255) NOT NULL COMMENT '內容',
  PRIMARY KEY (`wr_id`),
  UNIQUE KEY `wr_wt_id` (`wr_wt_id`,`wr_item`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='工作單價比例換算(困難度1)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workratio1_tab`
--

LOCK TABLES `workratio1_tab` WRITE;
/*!40000 ALTER TABLE `workratio1_tab` DISABLE KEYS */;
/*!40000 ALTER TABLE `workratio1_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workratio2_tab`
--

DROP TABLE IF EXISTS `workratio2_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workratio2_tab` (
  `wr_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `wr_wt_id` int NOT NULL COMMENT '表格編號(FK)',
  `wr_item` int NOT NULL COMMENT '項次',
  `wr_multiplier` double NOT NULL COMMENT '乘數',
  `wr_content` varchar(255) NOT NULL COMMENT '內容',
  PRIMARY KEY (`wr_id`),
  UNIQUE KEY `wr_wt_id` (`wr_wt_id`,`wr_item`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='工作單價比例換算(困難度2)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workratio2_tab`
--

LOCK TABLES `workratio2_tab` WRITE;
/*!40000 ALTER TABLE `workratio2_tab` DISABLE KEYS */;
/*!40000 ALTER TABLE `workratio2_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `worktable_tab`
--

DROP TABLE IF EXISTS `worktable_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `worktable_tab` (
  `wt_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `wt_item` varchar(255) NOT NULL COMMENT '表格編號',
  `wt_name` varchar(255) NOT NULL COMMENT '表格名稱',
  `wt_sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`wt_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='工作單價比例換算表(查表)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `worktable_tab`
--

LOCK TABLES `worktable_tab` WRITE;
/*!40000 ALTER TABLE `worktable_tab` DISABLE KEYS */;
/*!40000 ALTER TABLE `worktable_tab` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-25 16:00:17
