-- MySQL dump 10.13  Distrib 9.1.0, for Win64 (x86_64)
--
-- Host: localhost    Database: labor_db
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `labor_db`
--

/*!40000 DROP DATABASE IF EXISTS `labor_db`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `labor_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `labor_db`;

--
-- Table structure for table `systemsettings_tab`
--

DROP TABLE IF EXISTS `systemsettings_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `systemsettings_tab` (
  `ss_id` varchar(30) NOT NULL COMMENT '名稱(PK)',
  `ss_type` varchar(10) NOT NULL COMMENT '輸入類型',
  `ss_value` varchar(255) NOT NULL COMMENT '值',
  `ss_sort` tinyint NOT NULL COMMENT '排序',
  `ss_note` varchar(255) DEFAULT NULL COMMENT '說明',
  PRIMARY KEY (`ss_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='系統設定';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `systemsettings_tab`
--

LOCK TABLES `systemsettings_tab` WRITE;
/*!40000 ALTER TABLE `systemsettings_tab` DISABLE KEYS */;
INSERT INTO `systemsettings_tab` VALUES ('show_wp_id','text','TES0000000',2,'展示工作包的編號'),('supervisors','tags','306355,305995,306339',1,'管理者');
/*!40000 ALTER TABLE `systemsettings_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webpost_tab`
--

DROP TABLE IF EXISTS `webpost_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webpost_tab` (
  `wp_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '鍵值(PK)',
  `wp_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '網站名稱',
  `wp_content` mediumtext COMMENT '內容',
  `wp_sort` tinyint NOT NULL COMMENT '排序',
  `wp_ud_id` varchar(30) NOT NULL COMMENT '使用者編號(FK)',
  `wp_datetime` datetime NOT NULL COMMENT '修改時間',
  PRIMARY KEY (`wp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='網站內容';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webpost_tab`
--

LOCK TABLES `webpost_tab` WRITE;
/*!40000 ALTER TABLE `webpost_tab` DISABLE KEYS */;
INSERT INTO `webpost_tab` VALUES ('IndexContent','網頁內容','',1,'306355','2022-10-27 12:20:37');
/*!40000 ALTER TABLE `webpost_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workpackage_tab`
--

DROP TABLE IF EXISTS `workpackage_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workpackage_tab` (
  `wp_id` varchar(15) NOT NULL COMMENT '工程(工作)案號(PK)',
  `wp_ud_id` varchar(30) NOT NULL COMMENT '建立人員編號(FK)',
  `wp_ud_ids` varchar(500) DEFAULT NULL COMMENT '擁有者編號(FK)',
  `wp_design_ud_ids` varchar(100) DEFAULT NULL COMMENT '設計人員編號(FK)',
  `wp_supervisory_ud_ids` varchar(100) DEFAULT NULL COMMENT '監造人員編號(FK)',
  `wp_work_cd_id` int NOT NULL DEFAULT '0' COMMENT '點工-契約編號(FK)',
  `wp_name` varchar(255) NOT NULL COMMENT ' 工程(工作)名稱',
  `wp_contractor_ubn` varchar(20) DEFAULT NULL COMMENT '承攬商統編',
  `wp_contractor_name` varchar(50) NOT NULL COMMENT '承攬商名稱',
  `wp_address` varchar(250) DEFAULT NULL COMMENT '工程地點',
  `wp_award_type` tinyint NOT NULL DEFAULT '1' COMMENT '決標類型(1:總價決標,0:單價決標)',
  `wp_award_price` int DEFAULT '0' COMMENT '契約總金額',
  `wp_start_date` varchar(10) DEFAULT NULL COMMENT '開工日期',
  `wp_completion_date` varchar(10) DEFAULT NULL COMMENT '竣工日期',
  `wp_contract_date` varchar(50) DEFAULT NULL COMMENT '契約工期(竣工用)',
  `wp_add_subtract` int NOT NULL DEFAULT '0' COMMENT '追加減淨額(竣工用)',
  `wp_workorder_bind` tinyint NOT NULL DEFAULT '1' COMMENT '工作單號綁?(0:契約,1:工作通知/結算書)',
  `wp_modify_price` tinyint NOT NULL DEFAULT '0' COMMENT '可以修改「工作通知/結算書」中的「單價」?',
  `wp_show_input_num` int NOT NULL DEFAULT '50' COMMENT '當合約數量超過 × 筆時，顯示輸入框；否則，顯示下拉式選單',
  `wp_offset_float` tinyint NOT NULL DEFAULT '0' COMMENT '小數點計算偏移量(For MCA1150017)',
  `wp_status` tinyint NOT NULL DEFAULT '1' COMMENT '狀態(1:執行中,0:已竣工)',
  `wp_datetime` datetime NOT NULL COMMENT '建立時間',
  PRIMARY KEY (`wp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='工作包';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workpackage_tab`
--

LOCK TABLES `workpackage_tab` WRITE;
/*!40000 ALTER TABLE `workpackage_tab` DISABLE KEYS */;
INSERT INTO `workpackage_tab` VALUES ('MCA1050012','306762','m50013','306762','261505',347,'大林廠北區電氣零星修繕工作','75012703','大立水電行','大林煉油廠北區所轄範圍',1,0,'2021-07-15','2023-09-05','日曆天 2年',0,1,0,50,0,0,'2021-10-14 00:00:00'),('MCA1150009','242578','','','',0,'大林廠斷路器及接觸器維護保養工作','54037779','昱榮電機有限公司','大林煉油廠所轄各建物、工場、油槽區、油庫及外站等',1,0,'','2024-05-23','',0,1,0,50,0,0,'2024-05-20 09:27:34'),('MCA1150016','306762','m50013','305448','261505',452,'大林廠北區中小工程配電暨電氣改善工作','75012703','大立水電行','大林煉油廠北區所轄範圍',1,0,'2023-11-28','','',0,1,0,50,0,1,'2024-03-06 13:38:10'),('MCA1150017','306762','m50013','306762','261505',344,'大林廠北區電氣零星修繕工作','75012703','大立水電行','大林煉油廠北區所轄範圍',1,0,'','2025-03-17','日曆天 2年',0,1,0,50,1,0,'2023-07-06 11:10:26'),('MCA1250009','242578','','306762','246255,246387',4,'大林廠斷路器及接觸器維護保養工作','54037779','昱榮電機有限公司','大林煉油廠所轄各建物、工場、油槽區、油庫及外站等',0,10970000,'2024-05-08','','2年日曆天',0,1,0,50,0,1,'2024-05-21 14:14:06'),('MCA1350007','306762','m50013','306762','261505',355,'大林廠北區電氣零星修繕工作','75012703','大立水電行','大林煉油廠北區所轄範圍',0,19378050,'2025-03-18','','日曆天 2年',0,1,0,50,0,1,'2025-04-25 12:00:00'),('MDE1150002','267490','270458','','',0,'大林廠南區轉機元件車製零星工作','','景隆企業有限公司','',1,0,'','2024-04-30','',0,1,0,50,0,0,'2023-03-21 13:42:36'),('MEA0550011','305995','','','305995',0,'大林廠RFCC工場風險基準檢查分析及檢查規劃工作','86690807 ','挪威商立恩威驗證股份有限公司台灣分公司','大林廠/承商廠址',1,0,'2016-07-13','2017-05-17','',0,1,0,50,0,0,'2024-03-20 09:04:38'),('MEA0950020','306355','','307297','306355',0,'大林廠機械完整性(MI)技術支援與評估服務及設備可靠度輔導工作','76014406','國立高雄科技大學','大林煉油廠與承攬商辦公室',1,0,'2022-03-08','2023-10-11','600日曆天',0,1,0,50,0,0,'2024-04-02 10:29:27'),('MEB0550006','305995','','','305995',0,'大林廠/桃園廠專利製程與設備檢修技術服務工作','20740427','富台工程股份有限公司','大林廠/桃園廠',1,0,'2016-10-19','2018-10-19','2年日曆天或契約總金額滿',0,1,1,50,0,0,'2024-03-19 12:45:16'),('MEB1450022','306282','','306282','',0,'大林廠/桃園廠專利製程與設備檢修技術服務工作','','','',0,18450000,'2025-03-03','','',0,1,1,50,0,1,'2025-07-28 13:35:45'),('MEC0750004','305995','','305995','305057',0,'大林廠電腦化維修管理系統使用功能及操作介面改善工作','28114068','盟立科技股份有限公司','大林廠',1,0,'','2019-12-10','',0,1,0,50,0,0,'2024-03-19 14:43:42'),('MEC0950001','305995','','305995','306339',0,'大林廠電腦化維修管理系統版本升級工作','84218848','敦陽科技股份有限公司','大林煉油廠與承攬商辦公室',1,0,'2020-10-26','2021-11-29','400日曆天',0,1,0,50,0,0,'2024-03-19 15:45:53'),('MEC1150008','306673','','306673','306339',0,'大林廠專案文件管理軟體Bentley ProjectWise系統版本升級工作','16088678','大塚資訊科技股份有限公司','大林煉油廠',1,0,'','2024-05-01','',0,0,0,50,0,0,'2022-12-06 08:08:44'),('MEC1350002','306355','','306673','306339',0,'大林廠既有工場技術文件電子化及ProjectWise系統第二階段版本升級工作','16088678','大塚資訊科技股份有限公司','大林煉油廠',1,0,'2024-07-30','','',0,0,0,50,0,1,'2024-07-29 15:08:49'),('MEC1350006','0912031123','0912031123','305995','306339',0,'大林廠電腦化維修管理系統預防保養功能提升與設備可靠度完整性分析工作','84218848','敦陽科技股份有限公司','大林煉油廠與廠商辦公室',1,0,'2025-05-19','','',0,1,0,50,0,1,'2025-08-21 15:02:27'),('MHB1250012','307131','308170','','',0,'大林廠轄區及廠外綠地環境樹木花草修剪、栽植及維護等零星工作','59154613','協泰豐國際有限公司','大林煉油廠',1,0,'','2024-05-07','',0,1,0,50,0,0,'2024-03-18 15:07:48'),('TES0000000','306355','051381','306355','306355',29,'測試工程勞務包','00000000','測試公司','大林煉油廠',1,0,'2024-01-01','2024-04-24','',0,1,0,1000,0,1,'2024-04-08 15:17:57');
/*!40000 ALTER TABLE `workpackage_tab` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-26  8:00:12
