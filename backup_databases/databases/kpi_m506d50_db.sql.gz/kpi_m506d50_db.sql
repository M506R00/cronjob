-- MySQL dump 10.13  Distrib 9.1.0, for Win64 (x86_64)
--
-- Host: localhost    Database: kpi_m506d50_db
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `kpi_m506d50_db`
--

/*!40000 DROP DATABASE IF EXISTS `kpi_m506d50_db`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `kpi_m506d50_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `kpi_m506d50_db`;

--
-- Table structure for table `kpiabnormal_tab`
--

DROP TABLE IF EXISTS `kpiabnormal_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kpiabnormal_tab` (
  `ka_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK))',
  `ka_ke_id` int NOT NULL COMMENT 'ke_id(FK)',
  `ka_contractor` varchar(10) NOT NULL COMMENT '填報者編號(FK)',
  `ka_oldcontractor` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '舊陳辦人',
  `ka_assigned_department` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '被指派人之部門',
  `ka_ke_column` varchar(30) NOT NULL COMMENT '判斷ke欄位',
  `ka_measure` mediumtext NOT NULL COMMENT '改善/預防措施',
  `ka_duadate` date DEFAULT NULL COMMENT '預定完成日期',
  `ka_track` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '追蹤說明',
  `ka_finishdate` date DEFAULT NULL COMMENT '實際完成日期',
  `ka_returnreason` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '退回理由',
  `ka_status` int NOT NULL COMMENT '0(填報)/1(陳核中)/2(簽核完成)/3(追蹤完成)/4指派填寫完畢/5陳核退回',
  `ka_sign_contractor` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '改善陳核-陳辦人',
  `ka_sign_director` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '改善陳核-部門主管',
  `ka_sign_manager` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '改善陳核-部門經理',
  `ka_psmcontractor` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT 'PSM陳辦人',
  `ka_sign_psmcontractor` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '追蹤陳核-PSM陳辦人',
  `ka_sign_psmdirector` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '追蹤陳核-PSM主管',
  `ka_sign_psmmanager` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '追蹤陳核-安全副廠長',
  `ka_sign_returnreason` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '陳核階段退回理由',
  PRIMARY KEY (`ka_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kpiabnormal_tab`
--

LOCK TABLES `kpiabnormal_tab` WRITE;
/*!40000 ALTER TABLE `kpiabnormal_tab` DISABLE KEYS */;
/*!40000 ALTER TABLE `kpiabnormal_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kpientry_tab`
--

DROP TABLE IF EXISTS `kpientry_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kpientry_tab` (
  `ke_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `ke_kt_id` int NOT NULL COMMENT 'kpi項目表ID(FK)',
  `ke_year` int NOT NULL COMMENT '西元年',
  `ke_jan` int DEFAULT NULL COMMENT '1月',
  `ke_feb` int DEFAULT NULL COMMENT '2月',
  `ke_mar` int DEFAULT NULL COMMENT '3月',
  `ke_apr` int DEFAULT NULL COMMENT '4月',
  `ke_may` int DEFAULT NULL COMMENT '5月',
  `ke_jun` int DEFAULT NULL COMMENT '6月',
  `ke_jul` int DEFAULT NULL COMMENT '7月',
  `ke_aug` int DEFAULT NULL COMMENT '8月',
  `ke_sep` int DEFAULT NULL COMMENT '9月',
  `ke_oct` int DEFAULT NULL COMMENT '10月',
  `ke_nov` int DEFAULT NULL COMMENT '11月',
  `ke_dec` int DEFAULT NULL COMMENT '12月',
  `ke_Qone` double DEFAULT NULL COMMENT '第一季',
  `ke_Qtwo` double DEFAULT NULL COMMENT '第二季',
  `ke_Qthree` double DEFAULT NULL COMMENT '第三季',
  `ke_Qfour` double DEFAULT NULL COMMENT '第四季',
  `ke_yearvalue` double DEFAULT NULL COMMENT '年值',
  `ke_total` double DEFAULT NULL COMMENT '計算總額',
  `ke_track` int NOT NULL COMMENT '是否要填寫追蹤表(1/是，0/否)',
  PRIMARY KEY (`ke_id`),
  UNIQUE KEY `uk_ktid_year` (`ke_kt_id`,`ke_year`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kpientry_tab`
--

LOCK TABLES `kpientry_tab` WRITE;
/*!40000 ALTER TABLE `kpientry_tab` DISABLE KEYS */;
INSERT INTO `kpientry_tab` VALUES (1,11,2025,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,88.3,81.4,NULL,NULL,NULL,NULL,0),(3,13,2025,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,100,100,NULL,NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `kpientry_tab` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-26  8:00:07
