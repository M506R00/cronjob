-- MySQL dump 10.13  Distrib 9.1.0, for Win64 (x86_64)
--
-- Host: localhost    Database: labor_tes0000000_db
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `labor_tes0000000_db`
--

/*!40000 DROP DATABASE IF EXISTS `labor_tes0000000_db`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `labor_tes0000000_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `labor_tes0000000_db`;

--
-- Table structure for table `accountdetail_tab`
--

DROP TABLE IF EXISTS `accountdetail_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accountdetail_tab` (
  `ad_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `ad_al_id` int NOT NULL COMMENT '總表編號(FK)',
  `ad_cd_id` int NOT NULL COMMENT '契約編號(FK)',
  `ad_cr_id` int NOT NULL COMMENT '困難乘數編號(FK)',
  `ad_wr1_id` int NOT NULL COMMENT '困難度1編號(FK)',
  `ad_wr2_id` int NOT NULL COMMENT '困難度2編號(FK)',
  `ad_estimated_quantity` double NOT NULL DEFAULT '0' COMMENT '預估數量',
  `ad_billing_quantity` double NOT NULL DEFAULT '0' COMMENT '結算數量',
  `ad_workorder` varchar(50) DEFAULT NULL COMMENT '工作單號',
  `ad_changed_price` varchar(10) NOT NULL DEFAULT '0' COMMENT '更改單價',
  PRIMARY KEY (`ad_id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='工作通知/結算書(細表)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accountdetail_tab`
--

LOCK TABLES `accountdetail_tab` WRITE;
/*!40000 ALTER TABLE `accountdetail_tab` DISABLE KEYS */;
INSERT INTO `accountdetail_tab` VALUES (1,1,10,0,1,0,100,95,'','0'),(2,2,29,3,0,0,720,700,'','0'),(3,3,10,0,2,0,1700,1630,'','0'),(4,3,27,0,0,3,1500,1630,'','0'),(5,3,30,0,0,0,160,160,'','0'),(6,3,29,3,0,0,100,80,'','0'),(7,4,15,0,3,0,150,100,'','0'),(8,4,25,0,0,5,150,130,'','0'),(9,4,34,0,0,0,50,20,'','0'),(10,5,22,0,0,3,1650,1500,'','0'),(11,5,17,0,2,0,1500,1230,'','0'),(12,5,29,3,0,0,100,99,'','0'),(13,6,16,0,1,0,500,450,'','0'),(14,6,31,0,0,0,100,90,'','0'),(15,7,14,0,1,0,100,95,'','0'),(16,7,29,4,0,0,125,110,'','0'),(17,7,32,0,0,0,10,9,'','0'),(18,8,9,0,1,0,16,14,'','0'),(19,8,11,0,1,0,16,12,'','0'),(20,8,30,0,0,0,1,1,'','0'),(21,9,3,0,0,0,1,1,'','0'),(22,9,12,0,1,0,1,1,'','0'),(23,9,10,0,1,0,1,1,'','0'),(24,10,5,0,0,0,5,5,'','0'),(25,10,32,0,0,0,1,1,'','0'),(26,10,10,0,1,0,1,1,'','0');
/*!40000 ALTER TABLE `accountdetail_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accountlist_tab`
--

DROP TABLE IF EXISTS `accountlist_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accountlist_tab` (
  `al_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `al_us_id` varchar(15) NOT NULL COMMENT '部門編號(FK)',
  `al_ud_id` varchar(30) NOT NULL COMMENT '使用者編號(FK)',
  `al_item` varchar(10) NOT NULL DEFAULT '' COMMENT '工作通知次數',
  `al_applyorder` varchar(50) NOT NULL DEFAULT '' COMMENT '申請單號',
  `al_workorder` varchar(50) NOT NULL COMMENT '工作單號',
  `al_construction` varchar(255) NOT NULL COMMENT '施工圖說',
  `al_content` varchar(255) NOT NULL COMMENT '工作範圍說明',
  `al_multiplier` double NOT NULL DEFAULT '1' COMMENT '單價乘數',
  `al_deadline` int NOT NULL COMMENT '期限',
  `al_begindate` date NOT NULL COMMENT '開工日期',
  `al_enddate` date NOT NULL COMMENT '完工日期',
  `al_billed` tinyint NOT NULL DEFAULT '0' COMMENT '是否已請款(0:未請款,1:已請款)',
  `al_installment` tinyint NOT NULL DEFAULT '0' COMMENT '第幾期',
  `al_datetime` datetime NOT NULL COMMENT '建立時間',
  `al_updatedatetime` datetime NOT NULL COMMENT '更新時間',
  PRIMARY KEY (`al_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='工作通知/結算書(總表)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accountlist_tab`
--

LOCK TABLES `accountlist_tab` WRITE;
/*!40000 ALTER TABLE `accountlist_tab` DISABLE KEYS */;
INSERT INTO `accountlist_tab` VALUES (1,'A000200','306355','','','','','維生設施費、職業安全衛生管理人員',1,1,'2024-04-11','2024-04-11',0,0,'2024-04-11 14:21:39','2024-04-25 10:00:45'),(2,'M506A20','306355','1','','6004-255-6A00-15','','2024年 承攬商 春節在家待命工作人員(3名)',0.5,1,'2024-02-14','2024-02-14',1,1,'2024-04-09 10:58:59','2024-04-24 10:29:03'),(3,'M506F50','306355','20','','6004-255-6F50-15','','煉四組更換LED燈具工作',1,2,'2024-03-09','2024-03-10',0,0,'2024-04-09 11:02:31','2024-04-23 14:34:28'),(4,'M506B18','306355','21','','FM00-6B18','','B-409鍋爐停爐2樓汽機房照明拆裝檢修工作',1.2,1,'2024-04-01','2024-04-01',1,2,'2024-04-09 11:53:05','2024-04-24 10:29:18'),(5,'M505310','306355','2','','6004-255-5310-15','','事務課 餐廳大樓後方綠地接線箱更新',1,1,'2024-04-08','2024-04-08',1,1,'2024-04-09 11:55:42','2024-04-24 10:29:09'),(6,'M506F80','306355','','','6004-255-6F80-15','','廢水工場 C8401A線路不良檢修工作',1,1,'2024-04-02','2024-04-02',1,1,'2024-04-09 11:59:25','2024-04-24 11:46:14'),(7,'M506F60','306355','','','6004-255-6F60-15','','第十二蒸餾工場  P1212增設馬達配電工作(局限空間作業)',1.4,1,'2024-04-09','2024-04-09',0,0,'2024-04-09 12:44:57','2024-04-25 10:00:34'),(8,'M506D50','306355','','','','','ROC工場  裂解壓縮機房照明檢修工作(工單號碼：WO10004889、WO10004985、WO10005036)',1,3,'2024-04-15','2024-04-17',0,0,'2024-04-23 13:39:22','2024-04-25 10:02:16'),(9,'M505300','261891','','','456435132','','123456456',1,1,'2024-05-21','2024-05-21',0,0,'2024-05-21 15:33:40','2024-05-21 15:33:40'),(10,'M505110','305995','','','','','123456',1,1,'2024-05-24','2024-05-24',0,0,'2024-05-24 13:25:33','2024-05-24 13:25:33');
/*!40000 ALTER TABLE `accountlist_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accountprofitfee_tab`
--

DROP TABLE IF EXISTS `accountprofitfee_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accountprofitfee_tab` (
  `ap_al_id` int NOT NULL COMMENT '工作通知/結算書(總表)編號(PK)',
  `ap_pf_id` int NOT NULL COMMENT '利潤及管理費編號(PK)',
  `ap_estimated_quantity` double NOT NULL DEFAULT '0' COMMENT '預估數量',
  `ap_billing_quantity` double NOT NULL DEFAULT '0' COMMENT '結算數量',
  `ap_workorder` varchar(50) DEFAULT NULL COMMENT '工作單號',
  `ap_status` tinyint NOT NULL DEFAULT '0' COMMENT '0:不列入計算,1:列入計算',
  PRIMARY KEY (`ap_al_id`,`ap_pf_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='利潤及管理費的刪除表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accountprofitfee_tab`
--

LOCK TABLES `accountprofitfee_tab` WRITE;
/*!40000 ALTER TABLE `accountprofitfee_tab` DISABLE KEYS */;
INSERT INTO `accountprofitfee_tab` VALUES (1,9,1,1,'',1),(1,10,1,1,'',1),(2,8,0,0,'',0);
/*!40000 ALTER TABLE `accountprofitfee_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contractdata_tab`
--

DROP TABLE IF EXISTS `contractdata_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contractdata_tab` (
  `cd_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `cd_ct_id` int NOT NULL COMMENT '困難度換算表編號(FK)',
  `cd_wt_id` int NOT NULL COMMENT '換算表編號(FK)',
  `cd_item` varchar(10) NOT NULL COMMENT '項次',
  `cd_name` varchar(255) NOT NULL COMMENT '項目及說明',
  `cd_text` varchar(100) DEFAULT NULL COMMENT '結算書文字',
  `cd_unit` varchar(10) NOT NULL COMMENT '單位',
  `cd_quantity` int NOT NULL DEFAULT '1' COMMENT '數量',
  `cd_price` varchar(10) NOT NULL DEFAULT '0' COMMENT '單價',
  `cd_sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`cd_id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='契約';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contractdata_tab`
--

LOCK TABLES `contractdata_tab` WRITE;
/*!40000 ALTER TABLE `contractdata_tab` DISABLE KEYS */;
INSERT INTO `contractdata_tab` VALUES (1,0,0,'1','混凝土175Kg/cm²','','m³',235,'2032.04',1),(2,0,0,'2','混凝土210Kg/cm²','','m³',250,'2126.33',2),(3,0,0,'3','瀝青混凝土','','T',130,'1907.93',3),(4,0,0,'4','安裝模板','','m²',250,'159.72',4),(5,0,0,'5','安裝擋土板','','m²',120,'148.17',5),(6,1,0,'6','安裝打釘槍釘或基礎螺套','','處',650,'81.78',6),(7,0,0,'7','級配回填','','m³',80,'347.33',7),(8,0,1,'8','地下金屬管配管1/2\"~3/4\"','1/2\"~3/4\"','m',30,'23.09',8),(9,0,1,'9','地下金屬管配管1\"','1\"','m',20,'27.90',9),(10,0,1,'10','地下金屬管配管1-1/4\"','1-1/4\"','m',20,'32.71',10),(11,0,1,'11','地下金屬管配管1-1/2\"','1-1/2\"','m',20,'33.67',11),(12,0,1,'12','地下金屬管配管2\"','2\"','m',20,'43.30',12),(13,0,1,'13','地下金屬管配管2-1/2\"','2-1/2\"','m',20,'47.14',13),(14,0,1,'14','地下金屬管配管3\"','3\"','m',20,'61.58',14),(15,0,1,'15','地下金屬管配管4\"','4\"','m',10,'85.63',15),(16,0,1,'16','地下金屬管配管5\"','5\"','m',10,'106.80',16),(17,0,1,'17','地下金屬管配管6\"','6\"','m',10,'131.81',17),(18,0,2,'18','地下PVC管配管1/2\"~3/4\"','1/2\"~3/4\"','m',50,'23.09',18),(19,0,2,'19','地下PVC管配管1\"','1\"','m',40,'27.90',19),(20,0,2,'20','地下PVC管配管1-1/4\"','1-1/4\"','m',40,'32.71',20),(21,0,3,'21','配穿PE被覆PEX電纜600V 2Cx2.0mm²(含)以下，高5m(含)以下','2Cx2.0mm²','m',45,'9.62',21),(22,0,3,'22','配穿PE被覆PEX電纜600V 2Cx3.5mm²，高5m(含)以下','2Cx3.5mm²','m',40,'11.55',22),(23,0,3,'23','配穿PE被覆PEX電纜600V 2Cx5.5mm²，高5m(含)以下','2Cx5.5mm²','m',38,'11.55',23),(24,0,3,'24','配穿PE被覆PEX電纜600V 2Cx8mm²，高5m(含)以下','2Cx8mm²','m',35,'13.47',24),(25,0,3,'25','配穿PE被覆PEX電纜600V 2Cx14mm²，高5m(含)以下','2Cx14mm²','m',32,'18.28',25),(26,0,3,'26','配穿PE被覆PEX電纜600V 2Cx22mm²，高5m(含)以下','2Cx22mm²','m',30,'23.09',26),(27,0,3,'27','配穿PE被覆PEX電纜600V 2Cx38mm²，高5m(含)以下','2Cx38mm²','m',25,'32.71',27),(28,0,3,'28','配穿PE被覆PEX電纜600V 2Cx60mm²，高5m(含)以下','2Cx60mm²','m',20,'35.60',28),(29,2,0,'29','電氣檢修工','','工時',450,'189.54',29),(30,0,0,'30','職業安全衛生管理人員出勤費用','小時','小時',1000,'188.58',30),(31,0,0,'31','吊卡車租金','','小時',270,'717.76',31),(32,0,0,'32','剪刀式高空作業車租金(6公尺)(含搬運用拖車租金)','','日',30,'2827.74',32),(33,0,0,'33','剪刀式高空作業車租金(10公尺)(含搬運用拖車租金)','','日',25,'3217.4',33),(34,0,0,'34','高空作業車租金(12~14公尺)(含搬運用拖車租金)','','日',23,'4777.03',34),(35,0,0,'35','高空作業車租金(18公尺)(含搬運用拖車租金)','','日',18,'5848.86',35),(36,0,0,'36','高空作業車租金(20~21公尺)(含搬運用拖車租金)','','日',15,'6142.31',36);
/*!40000 ALTER TABLE `contractdata_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contractratio_tab`
--

DROP TABLE IF EXISTS `contractratio_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contractratio_tab` (
  `cr_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `cr_ct_id` int NOT NULL COMMENT '表格編號(FK)',
  `cr_item` int NOT NULL COMMENT '項次',
  `cr_multiplier` double NOT NULL COMMENT '乘數',
  `cr_content` varchar(255) NOT NULL COMMENT '內容',
  PRIMARY KEY (`cr_id`),
  UNIQUE KEY `cr_ct_id` (`cr_ct_id`,`cr_item`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='契約困難度換算表(乘數)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contractratio_tab`
--

LOCK TABLES `contractratio_tab` WRITE;
/*!40000 ALTER TABLE `contractratio_tab` DISABLE KEYS */;
INSERT INTO `contractratio_tab` VALUES (1,1,1,1,'安裝打釘槍釘或基礎螺絲'),(2,1,2,0.2,'鑽孔配設塑膠塞及固定用螺絲'),(3,2,1,1,'電氣檢修工'),(4,2,2,1.7,'電焊工');
/*!40000 ALTER TABLE `contractratio_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contracttable_tab`
--

DROP TABLE IF EXISTS `contracttable_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contracttable_tab` (
  `ct_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `ct_name` varchar(255) NOT NULL COMMENT '表格名稱',
  `ct_sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`ct_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='契約困難度換算表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contracttable_tab`
--

LOCK TABLES `contracttable_tab` WRITE;
/*!40000 ALTER TABLE `contracttable_tab` DISABLE KEYS */;
INSERT INTO `contracttable_tab` VALUES (1,'安裝打釘槍釘或基礎螺套',1),(2,'電氣檢修工',2);
/*!40000 ALTER TABLE `contracttable_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profitfee_tab`
--

DROP TABLE IF EXISTS `profitfee_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `profitfee_tab` (
  `pf_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `pf_from_cd_id` int NOT NULL DEFAULT '0' COMMENT '從契約編號(FK)',
  `pf_to_cd_id` int NOT NULL DEFAULT '0' COMMENT '到契約編號(FK)',
  `pf_excluded_cd_ids` varchar(100) DEFAULT NULL COMMENT '排除契約編號(FK)',
  `pf_tax` enum('G','S','P','F','T') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'G' COMMENT '費用類別(G:一般,S:工安環保費,P:利潤管理費,F:固定單價,T:營業稅)',
  `pf_item` varchar(50) NOT NULL COMMENT '項次',
  `pf_name` varchar(255) NOT NULL COMMENT '項目及說明',
  `pf_unit` varchar(50) NOT NULL COMMENT '單位',
  `pf_quantity` int NOT NULL DEFAULT '1' COMMENT '數量',
  `pf_price` varchar(10) NOT NULL DEFAULT '0' COMMENT '金額',
  `pf_percent` double NOT NULL COMMENT '百分比',
  `pf_sort` tinyint NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`pf_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='附加費用';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profitfee_tab`
--

LOCK TABLES `profitfee_tab` WRITE;
/*!40000 ALTER TABLE `profitfee_tab` DISABLE KEYS */;
INSERT INTO `profitfee_tab` VALUES (1,1,2,NULL,'G','一','材料部份(1~2項)','式',1,'1009112',0,1),(2,3,7,NULL,'G','二','連工帶料部份(3~7項)','式',1,'386684',0,2),(3,8,30,NULL,'G','三','工資部份(8~30項)','式',1,'290926',0,3),(4,31,36,NULL,'G','四','施工車輛租金部份(31~36項)','式',1,'666348',0,4),(5,1,2,NULL,'P','五','利潤及管理費(1~2項和之3%)','式',1,'30273',3,5),(6,3,7,NULL,'P','六','利潤及管理費(3~7項和之6.5%)','式',1,'25134',6.5,6),(7,8,30,NULL,'P','七','利潤及管理費(8~30項和之10%)','式',1,'29093',10,7),(8,3,29,NULL,'S','八','工安衛生環保管理及措施費(3~39項和之2%)','式',1,'9781',2,8),(9,0,0,NULL,'F','九','維生設施費(廠商不須報價)','套',1,'80000',0,9),(10,0,0,NULL,'F','十','職業安全衛生管理人員','人/日',220,'1200',0,10),(11,0,0,NULL,'T','十一','營業稅(一~十項和)x5%','式',1,'139568',5,11);
/*!40000 ALTER TABLE `profitfee_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `requestpayment_tab`
--

DROP TABLE IF EXISTS `requestpayment_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `requestpayment_tab` (
  `rp_installment` tinyint NOT NULL COMMENT '請款期數(PK)',
  `rp_date` date DEFAULT NULL COMMENT '請款日期',
  PRIMARY KEY (`rp_installment`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='請款歸檔';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `requestpayment_tab`
--

LOCK TABLES `requestpayment_tab` WRITE;
/*!40000 ALTER TABLE `requestpayment_tab` DISABLE KEYS */;
INSERT INTO `requestpayment_tab` VALUES (1,'2024-03-11'),(2,'2024-04-02');
/*!40000 ALTER TABLE `requestpayment_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workratio1_tab`
--

DROP TABLE IF EXISTS `workratio1_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workratio1_tab` (
  `wr_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `wr_wt_id` int NOT NULL COMMENT '表格編號(FK)',
  `wr_item` int NOT NULL COMMENT '項次',
  `wr_multiplier` double NOT NULL COMMENT '乘數',
  `wr_content` varchar(255) NOT NULL COMMENT '內容',
  PRIMARY KEY (`wr_id`),
  UNIQUE KEY `wr_wt_id` (`wr_wt_id`,`wr_item`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='工作單價比例換算(困難度1)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workratio1_tab`
--

LOCK TABLES `workratio1_tab` WRITE;
/*!40000 ALTER TABLE `workratio1_tab` DISABLE KEYS */;
INSERT INTO `workratio1_tab` VALUES (1,1,1,1,'一般地下金屬管配管'),(2,1,2,1.2,'建築物樓板埋設金屬管配管'),(3,1,3,1.2,'含防蝕處理金屬管配管'),(4,1,4,0.5,'拆除地下金屬管'),(5,2,1,1,'一般地下PVC配管'),(6,2,2,1.2,'建築物樓板埋設PVC配管'),(7,2,3,0.5,'拆除地下PVC配管');
/*!40000 ALTER TABLE `workratio1_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workratio2_tab`
--

DROP TABLE IF EXISTS `workratio2_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workratio2_tab` (
  `wr_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `wr_wt_id` int NOT NULL COMMENT '表格編號(FK)',
  `wr_item` int NOT NULL COMMENT '項次',
  `wr_multiplier` double NOT NULL COMMENT '乘數',
  `wr_content` varchar(255) NOT NULL COMMENT '內容',
  PRIMARY KEY (`wr_id`),
  UNIQUE KEY `wr_wt_id` (`wr_wt_id`,`wr_item`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='工作單價比例換算(困難度2)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workratio2_tab`
--

LOCK TABLES `workratio2_tab` WRITE;
/*!40000 ALTER TABLE `workratio2_tab` DISABLE KEYS */;
INSERT INTO `workratio2_tab` VALUES (1,3,1,1,'PE PEX電纜'),(2,3,2,0.9,'PVC電纜'),(3,3,3,1.2,'6KV PEX電纜'),(4,3,4,1.5,'15KV PEX電纜'),(5,3,5,1.65,'25KV PEX電纜');
/*!40000 ALTER TABLE `workratio2_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `worktable_tab`
--

DROP TABLE IF EXISTS `worktable_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `worktable_tab` (
  `wt_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `wt_item` varchar(255) NOT NULL COMMENT '表格編號',
  `wt_name` varchar(255) NOT NULL COMMENT '表格名稱',
  `wt_sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`wt_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='工作單價比例換算表(查表)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `worktable_tab`
--

LOCK TABLES `worktable_tab` WRITE;
/*!40000 ALTER TABLE `worktable_tab` DISABLE KEYS */;
INSERT INTO `worktable_tab` VALUES (1,'表1','地下金屬管配管',1),(2,'表2','地下PVC配管',2),(3,'表3','PE PEX絕緣電纜配穿 2C或3C',3);
/*!40000 ALTER TABLE `worktable_tab` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-24 16:00:18
