-- MySQL dump 10.13  Distrib 9.1.0, for Win64 (x86_64)
--
-- Host: localhost    Database: ca_db
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ca_db`
--

/*!40000 DROP DATABASE IF EXISTS `ca_db`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ca_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `ca_db`;

--
-- Table structure for table `answer_tab`
--

DROP TABLE IF EXISTS `answer_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `answer_tab` (
  `as_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `as_us_id` varchar(10) NOT NULL COMMENT '部門編號(FK)',
  `as_ud_id` varchar(30) NOT NULL COMMENT '人員編號(FK)',
  `as_qt_id` int NOT NULL COMMENT '題目編號(FK)',
  `as_ot_id` varchar(50) DEFAULT NULL COMMENT '選項編號(FK)',
  `as_note` text COMMENT '備註',
  `as_datetime` datetime NOT NULL COMMENT '建立時間',
  PRIMARY KEY (`as_id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='答案';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `answer_tab`
--

LOCK TABLES `answer_tab` WRITE;
/*!40000 ALTER TABLE `answer_tab` DISABLE KEYS */;
/*!40000 ALTER TABLE `answer_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `itemgroup_tab`
--

DROP TABLE IF EXISTS `itemgroup_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `itemgroup_tab` (
  `ig_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `ig_pe_id` tinyint NOT NULL COMMENT 'PSM要素編號(FK)',
  `ig_name` varchar(255) NOT NULL COMMENT '名稱',
  `ig_sort` int NOT NULL COMMENT '排序',
  `ig_status` tinyint NOT NULL DEFAULT '1' COMMENT '狀態',
  PRIMARY KEY (`ig_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='項次群組';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `itemgroup_tab`
--

LOCK TABLES `itemgroup_tab` WRITE;
/*!40000 ALTER TABLE `itemgroup_tab` DISABLE KEYS */;
INSERT INTO `itemgroup_tab` VALUES (1,1,'激勵部門所有員工積',1,1),(2,1,'提高製程安全意識，參與製程安全管理14項目，強化製程安全及其管理績效',2,1),(3,2,'蒐集、彙整、建立正確且充分之製程安全三大資訊，並據以辨識、評估工作場所潛在危害',1,1),(4,2,'採取必要之控制設施，確保製程操作安全無虞',2,1);
/*!40000 ALTER TABLE `itemgroup_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `option_tab`
--

DROP TABLE IF EXISTS `option_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `option_tab` (
  `ot_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `ot_name` varchar(255) NOT NULL COMMENT '名稱',
  `ot_ratio` float NOT NULL DEFAULT '0' COMMENT '分數佔比',
  PRIMARY KEY (`ot_id`),
  UNIQUE KEY `ot_name` (`ot_name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='稽核選項';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `option_tab`
--

LOCK TABLES `option_tab` WRITE;
/*!40000 ALTER TABLE `option_tab` DISABLE KEYS */;
INSERT INTO `option_tab` VALUES (0,'不適用(-)',0),(1,'不符合(0%)',0),(2,'部分符合(30%)',0),(3,'基本符合(50%)',0),(4,'高度符合(80%)',0),(5,'完全符合(100%)',0);
/*!40000 ALTER TABLE `option_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `psmelement_tab`
--

DROP TABLE IF EXISTS `psmelement_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `psmelement_tab` (
  `pe_id` tinyint NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `pe_name` varchar(25) NOT NULL COMMENT '名稱',
  PRIMARY KEY (`pe_id`),
  UNIQUE KEY `pm_name` (`pe_name`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='PSM要素';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `psmelement_tab`
--

LOCK TABLES `psmelement_tab` WRITE;
/*!40000 ALTER TABLE `psmelement_tab` DISABLE KEYS */;
INSERT INTO `psmelement_tab` VALUES (11,'事故調查'),(9,'動火許可'),(1,'勞工參與'),(14,'商業機密'),(7,'啟動前安全檢查'),(6,'承攬管理'),(5,'教育訓練'),(4,'標準程序'),(8,'機械完整性'),(13,'符合性稽查'),(12,'緊急應變'),(3,'製程危害分析'),(2,'製程安全資訊'),(10,'變更管理');
/*!40000 ALTER TABLE `psmelement_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_tab`
--

DROP TABLE IF EXISTS `question_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `question_tab` (
  `qt_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `qt_ig_id` int NOT NULL COMMENT '項次群組編號(FK)',
  `qt_item` varchar(10) DEFAULT NULL COMMENT '次項目',
  `qt_name` varchar(255) NOT NULL COMMENT '稽核項目',
  `qt_score` tinyint NOT NULL DEFAULT '5' COMMENT '本項評定配分',
  `qt_ot_id1` int NOT NULL DEFAULT '5' COMMENT '選項A',
  `qt_ot_id2` int NOT NULL DEFAULT '4' COMMENT '選項B',
  `qt_ot_id3` int NOT NULL DEFAULT '3' COMMENT '選項C',
  `qt_ot_id4` int NOT NULL DEFAULT '2' COMMENT '選項D',
  `qt_ot_id5` int NOT NULL DEFAULT '1' COMMENT '選項E',
  `qt_ot_id6` int NOT NULL DEFAULT '0' COMMENT '選項F',
  `qt_status` tinyint NOT NULL DEFAULT '1' COMMENT '狀態(1:開啟; 0:關閉)',
  PRIMARY KEY (`qt_id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='稽核題目';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question_tab`
--

LOCK TABLES `question_tab` WRITE;
/*!40000 ALTER TABLE `question_tab` DISABLE KEYS */;
INSERT INTO `question_tab` VALUES (1,1,'1','部門主管向所屬員工宣導及溝通製程安/工安全管理資訊，如廠內PSM或OSM工安推動宣導事項，並留有紀錄',5,5,4,3,2,1,0,1),(2,1,'2','鼓勵所屬員工積極接受製程相關操作及製程安全管理之訓練，提高工作職能，並符合達至熟悉級(Familiar)程度',3,5,4,3,2,1,0,1),(3,1,'3','鼓勵專業豐富及技術專精級作業之，擔任講師，傳授作業經驗與要領，並留有實施訓練紀錄佐證',2,5,4,3,2,1,0,1),(4,1,'4','部門主管應適時激(獎)勵勞工參與製程安全管理之相關作為，如確認員工遵守SOP/WI及其他要求',4,5,4,3,2,1,0,1),(5,1,'5','部門主管對有發現重大、有立即危害、虛驚事件等之員工，提報工安優良事蹟英雄榜',5,5,4,3,2,1,0,1),(6,1,'6','部門主管規劃員工參與之項目、方式及辦理促進勞工參與之活動，如設備正確操作、責任區設備保養等',3,5,4,3,2,1,0,1),(7,2,'1','確實瞭解個人及部門在製程安全管理之角色及責任，如現場巡檢、三級保養、自動檢查等之執行',5,5,4,3,2,1,0,1),(8,2,'2','了解現場之PSI危害物、技術、設備三大之資訊，並提供有安全之虞之改善建議或提案，強化製程安全及其管理績效',5,5,4,3,2,1,0,1),(9,2,'3','製程安全資訊(PSI) : 如參與P&ID與現場之比對及更新',5,5,4,3,2,1,0,1),(10,2,'4','製程安全分析(PHA) : 如參與製程安全評估研討，俾辨識製程潛在之顧慮或問題',5,5,4,3,2,1,0,1),(11,2,'5','標準作業程序(OP) : 如操作程序定期由部門主管帶領其勞工進行實際操作狀況檢討及更新，將有助於決定與安全有關之關鍵性步驟',2,5,4,3,2,1,0,1),(12,2,'6','教育訓練(TR) : 如現場所需訓練取得之證書(照)，符合法規對低要求，如防火管理員、乙級鍋爐操作人員等',8,5,4,3,2,1,0,1),(13,2,'7','承攬商管理(CON) : 如提報或糾正承攬人施工期間之潛在問題，例如高處作業未穿戴安全帶或避免發生危害之管理事項，例如A級工作三方會勘等',8,5,4,3,2,1,0,1),(14,2,'8','啟動前安全檢查(PSSR) : 如確定設備已備妥各項要求狀況，並可安全啟動或開俥',10,5,4,3,2,1,0,1),(15,2,'9','機械完整性(MI): 如操作及維修保養之員工提出設備可靠度之維護或改進建議',5,5,4,3,2,1,0,1),(16,2,'10','動火許可(HWP) : 如操作、維修之員工及承攬商，對涉及動火作業已排除危害物、隔離盲封程序完備',6,5,4,3,2,1,0,1),(17,2,'11','變更管理(MOC) : 如發現未符合規定之變更或懷疑適當性，主動向主管報告疑慮之處或進行討論',4,5,4,3,2,1,0,1),(18,2,'12','事故調查(II) : 如事故調查小組由部門主管根據事故嚴重性及性質選擇成員，包括專業員工及其代表(如領班)等',10,5,4,3,2,1,0,1),(19,2,'13','緊急應變(EPR) : 如透過演習及實際緊急狀況之處理結果，對應變計畫進行回饋',8,5,4,3,2,1,0,1),(20,2,'14','符合性稽核(CA) : 如確認PSM相關程序及規定被遵循且有效執行',12,5,4,3,2,1,0,1),(21,2,'15','商業機密(TS) : 如需取閱管制性機密文件時，確實遵守本公司保密規定，如交給承攬商，應填寫保密切結書並蓋承攬商公司之印記',10,5,4,3,2,1,0,1),(22,3,'1','是否置備危害性化學品清單？',5,5,4,3,2,1,0,1),(23,3,'2','是否有安全資料表(SDS)？',5,5,4,3,2,1,0,1),(24,3,'3','高度危險化學品的危害資訊，是否有以下危害資訊：(一)毒性資訊。(二)容許暴露濃度。(三)物理數據。(四)反應性數據。(五)腐蝕性數據。(六)熱及化學安定性數據。(七)可能發生不慎與其他物質混合危害後果。',5,5,4,3,2,1,0,1),(25,3,'4','是否有方塊流程圖或簡化製程流程圖(PFD)？',10,5,4,3,2,1,0,1),(26,3,'5','是否有質能平衡資料？',5,5,4,3,2,1,0,1),(27,3,'6','是否有製程化學反應資料？(如製程反應方程式、副反應、反應熱等相關資料)',5,5,4,3,2,1,0,1),(28,3,'7','是否有預期最大存量資料表？',5,5,4,3,2,1,0,1),(29,3,'8','是否有溫度、壓力、流量或組成等之安全上、下限？(如異常或失控反應資料)',5,5,4,3,2,1,0,1),(30,3,'9','是否有管線與儀錶圖(Piping and Instrumentation Diagrams P&IDs)？',5,5,4,3,2,1,0,1),(31,4,'1','是否有安全系統如安全連鎖跳俥(ESD)設計相關資料？\r\n',5,5,4,3,2,1,0,1),(32,4,'2','是否有安全系統如安全儀錶系統(SIS)邏輯圖？',5,5,4,3,2,1,0,1),(33,4,'3','是否有氣體偵測器、火焰偵測器等清單及相關資料？',5,5,4,3,2,1,0,1),(34,4,'4','是否有CCTV監視系統清單？',5,5,4,3,2,1,0,1),(35,4,'5','是否有消防水系統、反應冷卻水系統相關資料？',5,5,4,3,2,1,0,1),(36,4,'6','是否有緩衝、抑制設施(如灑水裝置、蒸氣環)清單？',5,5,4,3,2,1,0,1),(37,4,'7','是否有防爆區域劃分圖資及相關資料？',5,5,4,3,2,1,0,1),(38,4,'8','是否有釋壓系統設計及設計依據？(包含安全閥、破裂盤、呼吸閥、釋放閥、Flare系統)',5,5,4,3,2,1,0,1),(39,4,'9','是否有設備通風系統設計？',5,5,4,3,2,1,0,1),(40,4,'10','是否有高低壓差大於10倍之防止逆流設計及裝置清單？',5,5,4,3,2,1,0,1),(41,4,'11','緊急遮斷閥(ESV)，包括MOV、POV 、EOV等清單及相關資料？',5,5,4,3,2,1,0,1),(42,4,'12','是否有設備建造結構材料清單？',5,5,4,3,2,1,0,1),(43,4,'13','是否有使用之設計規範及標準？',5,5,4,3,2,1,0,1),(44,4,'14','是否有製程偏移後果評估，包括可能影響勞工安全及健康事項？',5,5,4,3,2,1,0,1),(45,4,'15','是否有製程設備之設計、製造及操作符合相關法令規定之證明文件？',5,5,4,3,2,1,0,1),(46,4,'16','是否有製程設備設計資料(Data Sheet)？',5,5,4,3,2,1,0,1),(47,4,'17','建置危險性工作場所資訊',5,5,4,3,2,1,0,1);
/*!40000 ALTER TABLE `question_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `systemsettings_tab`
--

DROP TABLE IF EXISTS `systemsettings_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `systemsettings_tab` (
  `ss_id` varchar(30) NOT NULL COMMENT '名稱(PK)',
  `ss_type` varchar(10) NOT NULL COMMENT '輸入類型',
  `ss_value` varchar(255) NOT NULL COMMENT '值',
  `ss_sort` tinyint NOT NULL COMMENT '排序',
  `ss_note` varchar(255) DEFAULT NULL COMMENT '說明',
  PRIMARY KEY (`ss_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='系統設定';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `systemsettings_tab`
--

LOCK TABLES `systemsettings_tab` WRITE;
/*!40000 ALTER TABLE `systemsettings_tab` DISABLE KEYS */;
INSERT INTO `systemsettings_tab` VALUES ('supervisors','tags','306355,306339,730220',1,'管理者');
/*!40000 ALTER TABLE `systemsettings_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webpost_tab`
--

DROP TABLE IF EXISTS `webpost_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webpost_tab` (
  `wp_id` varchar(100) NOT NULL COMMENT '名稱(PK)',
  `wp_name` varchar(45) NOT NULL COMMENT '網站名稱',
  `wp_content` mediumtext COMMENT '內容',
  `wp_sort` tinyint NOT NULL COMMENT '排序',
  `wp_ud_id` varchar(30) NOT NULL COMMENT '使用者編號(FK)',
  `wp_datetime` datetime NOT NULL COMMENT '修改時間',
  PRIMARY KEY (`wp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='網站內容';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webpost_tab`
--

LOCK TABLES `webpost_tab` WRITE;
/*!40000 ALTER TABLE `webpost_tab` DISABLE KEYS */;
INSERT INTO `webpost_tab` VALUES ('IndexContent','網頁內容',NULL,1,'','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `webpost_tab` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-25 16:01:50
