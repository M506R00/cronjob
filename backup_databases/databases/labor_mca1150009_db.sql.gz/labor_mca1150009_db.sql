-- MySQL dump 10.13  Distrib 9.1.0, for Win64 (x86_64)
--
-- Host: localhost    Database: labor_mca1150009_db
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `labor_mca1150009_db`
--

/*!40000 DROP DATABASE IF EXISTS `labor_mca1150009_db`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `labor_mca1150009_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `labor_mca1150009_db`;

--
-- Table structure for table `accountdetail_tab`
--

DROP TABLE IF EXISTS `accountdetail_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accountdetail_tab` (
  `ad_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `ad_al_id` int NOT NULL COMMENT '總表編號(FK)',
  `ad_cd_id` int NOT NULL COMMENT '契約編號(FK)',
  `ad_cr_id` int NOT NULL COMMENT '困難乘數編號(FK)',
  `ad_wr1_id` int NOT NULL COMMENT '困難度1編號(FK)',
  `ad_wr2_id` int NOT NULL COMMENT '困難度2編號(FK)',
  `ad_estimated_quantity` double NOT NULL DEFAULT '0' COMMENT '預估數量',
  `ad_billing_quantity` double NOT NULL DEFAULT '0' COMMENT '結算數量',
  `ad_workorder` varchar(50) DEFAULT NULL COMMENT '工作單號',
  `ad_changed_price` varchar(10) NOT NULL DEFAULT '0' COMMENT '更改單價',
  PRIMARY KEY (`ad_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='工作通知/結算書(細表)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accountdetail_tab`
--

LOCK TABLES `accountdetail_tab` WRITE;
/*!40000 ALTER TABLE `accountdetail_tab` DISABLE KEYS */;
/*!40000 ALTER TABLE `accountdetail_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accountlist_tab`
--

DROP TABLE IF EXISTS `accountlist_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accountlist_tab` (
  `al_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `al_us_id` varchar(15) NOT NULL COMMENT '部門編號(FK)',
  `al_ud_id` varchar(30) NOT NULL COMMENT '使用者編號(FK)',
  `al_item` varchar(10) NOT NULL DEFAULT '' COMMENT '工作通知次數',
  `al_applyorder` varchar(50) NOT NULL DEFAULT '' COMMENT '申請單號',
  `al_workorder` varchar(50) NOT NULL COMMENT '工作單號',
  `al_construction` varchar(255) NOT NULL COMMENT '施工圖說',
  `al_content` varchar(255) NOT NULL COMMENT '工作範圍說明',
  `al_multiplier` double NOT NULL DEFAULT '1' COMMENT '單價乘數',
  `al_deadline` int NOT NULL COMMENT '期限',
  `al_begindate` date NOT NULL COMMENT '開工日期',
  `al_enddate` date NOT NULL COMMENT '完工日期',
  `al_billed` tinyint NOT NULL DEFAULT '0' COMMENT '是否已請款(0:未請款,1:已請款)',
  `al_installment` tinyint NOT NULL DEFAULT '0' COMMENT '第幾期',
  `al_datetime` datetime NOT NULL COMMENT '建立時間',
  `al_updatedatetime` datetime NOT NULL COMMENT '更新時間',
  PRIMARY KEY (`al_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='工作通知/結算書(總表)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accountlist_tab`
--

LOCK TABLES `accountlist_tab` WRITE;
/*!40000 ALTER TABLE `accountlist_tab` DISABLE KEYS */;
/*!40000 ALTER TABLE `accountlist_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accountprofitfee_tab`
--

DROP TABLE IF EXISTS `accountprofitfee_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accountprofitfee_tab` (
  `ap_al_id` int NOT NULL COMMENT '工作通知/結算書(總表)編號(PK)',
  `ap_pf_id` int NOT NULL COMMENT '利潤及管理費編號(PK)',
  `ap_estimated_quantity` double NOT NULL DEFAULT '0' COMMENT '預估數量',
  `ap_billing_quantity` double NOT NULL DEFAULT '0' COMMENT '結算數量',
  `ap_workorder` varchar(50) DEFAULT NULL COMMENT '工作單號',
  `ap_status` tinyint NOT NULL DEFAULT '0' COMMENT '0:不列入計算,1:列入計算',
  PRIMARY KEY (`ap_al_id`,`ap_pf_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='利潤及管理費的刪除表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accountprofitfee_tab`
--

LOCK TABLES `accountprofitfee_tab` WRITE;
/*!40000 ALTER TABLE `accountprofitfee_tab` DISABLE KEYS */;
/*!40000 ALTER TABLE `accountprofitfee_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contractdata_tab`
--

DROP TABLE IF EXISTS `contractdata_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contractdata_tab` (
  `cd_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `cd_ct_id` int NOT NULL COMMENT '困難度換算表編號(FK)',
  `cd_wt_id` int NOT NULL COMMENT '換算表編號(FK)',
  `cd_item` varchar(10) NOT NULL COMMENT '項次',
  `cd_name` varchar(255) NOT NULL COMMENT '項目及說明',
  `cd_text` varchar(100) DEFAULT NULL COMMENT '結算書文字',
  `cd_unit` varchar(10) NOT NULL COMMENT '單位',
  `cd_quantity` int NOT NULL DEFAULT '1' COMMENT '數量',
  `cd_price` varchar(10) NOT NULL DEFAULT '0' COMMENT '單價',
  `cd_sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`cd_id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='契約';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contractdata_tab`
--

LOCK TABLES `contractdata_tab` WRITE;
/*!40000 ALTER TABLE `contractdata_tab` DISABLE KEYS */;
INSERT INTO `contractdata_tab` VALUES (1,0,0,'1','高壓斷路器維護保養(GCB、VCB)','','ST',100,'13831',1),(2,0,0,'2','高壓接觸器維護保養(GCS、VCS)','','ST',60,'10806',2),(3,0,0,'3','低壓斷路器維護保養(ACB)','','ST',70,'10806',3),(4,0,0,'4','電氣檢修工','','小時',400,'174',4),(5,0,0,'5','GCB絕緣套管更換','','ST',10,'2483',5),(6,0,0,'6','控制線組更換','','ST',5,'4464',6),(7,0,0,'7','ACB轉接套件更換','','SET',5,'33480',7),(8,0,0,'8','儲能馬達','','PC',1,'28131',8),(9,0,0,'9','投入線圈','','PC',1,'7672',9),(10,0,0,'10','跳脫線圈','','PC',1,'7672',10),(11,0,0,'11','輔助接點組','','PC',1,'7448',11),(12,0,0,'12','微動開關','','PC',1,'7672',12),(13,0,0,'13','ON/OFF手動操作連動機構組','','PC',1,'17901',13),(14,0,0,'14','控制線組','','PC',1,'62657',14),(15,0,0,'15','斷路器引出入機構','','PC',1,'17901',15),(16,0,0,'16','消弧室1250A以下','','PC',1,'17901',16),(17,0,0,'17','消弧室1600A以上','','PC',1,'40918',17),(18,0,0,'18','斷路器框架 1250A以下','','PC',1,'17901',18),(19,0,0,'19','斷路器框架 1600A以上','','PC',1,'40918',19),(20,0,0,'20','絕緣套管 1250A以下','','PC',1,'10229',20),(21,0,0,'21','絕緣套管 1600A以上','','PC',1,'17901',21),(22,0,0,'22','控制電路板','','PC',1,'12788',22),(23,0,0,'23','投入線圈','','PC',1,'15345',23),(24,0,0,'24','跳脫線圈','','PC',1,'7672',24),(25,0,0,'25','輔助接點組','','PC',1,'5115',25),(26,0,0,'26','微動開關','','PC',1,'767',26),(27,0,0,'27','控制線組','','PC',1,'25574',27),(28,0,0,'28','消弧室 FOR GCS 三相共管','','PC',1,'51148',28),(29,0,0,'29','消弧室 FOR VCS 單相單管','','PC',1,'12788',29),(30,0,0,'30','接觸器框架 FOR GCS','','PC',1,'17901',30),(31,0,0,'31','接觸器框架 FOR VCS','','PC',1,'12788',31),(32,0,0,'32','絕緣套管 FOR GCS','','PC',1,'10229',32),(33,0,0,'33','絕緣套管 FOR VCS','','PC',1,'10229',33),(34,0,0,'34','儲能馬達','','PC',1,'20460',34),(35,0,0,'35','投入線圈','','PC',1,'15345',35),(36,0,0,'36','跳脫線圈','','PC',1,'15345',36),(37,0,0,'37','低電壓跳脫線圈','','PC',1,'22346',37),(38,0,0,'38','NW OCR控制單元','','PC',1,'17294',38),(39,0,0,'39','輔助接點組','','PC',1,'4348',39),(40,0,0,'40','微動開關','','PC',1,'767',40),(41,0,0,'41','ON/OFF手動操作連動機構組','','PC',1,'24830',41),(42,0,0,'42','控制線組','','PC',1,'12788',42),(43,0,0,'43','斷路器引出入機構','','PC',1,'12788',43),(44,0,0,'44','斷路器框架 3P 1600A以下','','PC',1,'17901',44),(45,0,0,'45','斷路器框架 3P 2000A~2500A','','PC',1,'25574',45),(46,0,0,'46','斷路器框架 3P 3200A~4000A','','PC',1,'38360',46),(47,0,0,'47','斷路器ACB本體 3P 1600A以下','','PC',1,'139162',47),(48,0,0,'48','斷路器ACB本體 3P 2000A~2500A','','PC',1,'166994',48),(49,0,0,'49','斷路器ACB本體 3P 3200A~4000A','','PC',1,'194827',49),(50,0,0,'50','ACB轉接銅排(M->NW type) 水平3P 800-1600A','','SET',1,'33480',50),(51,0,0,'51','ACB轉接銅排(M->NW type) 水平3P 2000-2500A','','SET',1,'35712',51),(52,0,0,'52','ACB轉接銅排(M->NW type) 水平3P 3200A','','SET',1,'41850',52),(53,0,0,'53','ACB轉接銅排(M->NW type) 水平3P 4000A','','SET',1,'44640',53),(54,0,0,'54','ACB轉接銅排(M->NW type) 垂直3P 800-1600A','','SET',1,'35712',54),(55,0,0,'55','ACB轉接銅排(M->NW type) 垂直3P 2000-2500A','','SET',1,'37944',55),(56,0,0,'56','ACB轉接銅排(M->NW type) 垂直3P 3200A','','SET',1,'46314',56),(57,0,0,'57','ACB轉接銅排(M->NW type) 垂直3P 4000A','','SET',1,'61380',57);
/*!40000 ALTER TABLE `contractdata_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contractratio_tab`
--

DROP TABLE IF EXISTS `contractratio_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contractratio_tab` (
  `cr_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `cr_ct_id` int NOT NULL COMMENT '表格編號(FK)',
  `cr_item` int NOT NULL COMMENT '項次',
  `cr_multiplier` double NOT NULL COMMENT '乘數',
  `cr_content` varchar(255) NOT NULL COMMENT '內容',
  PRIMARY KEY (`cr_id`),
  UNIQUE KEY `cr_ct_id` (`cr_ct_id`,`cr_item`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='契約困難度換算表(乘數)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contractratio_tab`
--

LOCK TABLES `contractratio_tab` WRITE;
/*!40000 ALTER TABLE `contractratio_tab` DISABLE KEYS */;
/*!40000 ALTER TABLE `contractratio_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contracttable_tab`
--

DROP TABLE IF EXISTS `contracttable_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contracttable_tab` (
  `ct_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `ct_name` varchar(255) NOT NULL COMMENT '表格名稱',
  `ct_sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`ct_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='契約困難度換算表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contracttable_tab`
--

LOCK TABLES `contracttable_tab` WRITE;
/*!40000 ALTER TABLE `contracttable_tab` DISABLE KEYS */;
/*!40000 ALTER TABLE `contracttable_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profitfee_tab`
--

DROP TABLE IF EXISTS `profitfee_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `profitfee_tab` (
  `pf_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `pf_from_cd_id` int NOT NULL DEFAULT '0' COMMENT '從契約編號(FK)',
  `pf_to_cd_id` int NOT NULL DEFAULT '0' COMMENT '到契約編號(FK)',
  `pf_excluded_cd_ids` varchar(100) DEFAULT NULL COMMENT '排除契約編號(FK)',
  `pf_tax` enum('G','S','P','F','T') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'G' COMMENT '費用類別(G:一般,S:工安環保費,P:利潤管理費,F:固定單價,T:營業稅)',
  `pf_item` varchar(50) NOT NULL COMMENT '項次',
  `pf_name` varchar(255) NOT NULL COMMENT '項目及說明',
  `pf_unit` varchar(50) NOT NULL COMMENT '單位',
  `pf_quantity` int NOT NULL DEFAULT '1' COMMENT '數量',
  `pf_price` varchar(10) NOT NULL DEFAULT '0' COMMENT '金額',
  `pf_percent` double NOT NULL COMMENT '百分比',
  `pf_sort` tinyint NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`pf_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='附加費用';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profitfee_tab`
--

LOCK TABLES `profitfee_tab` WRITE;
/*!40000 ALTER TABLE `profitfee_tab` DISABLE KEYS */;
INSERT INTO `profitfee_tab` VALUES (1,1,7,NULL,'G','一','工資部分(1~7項)','式',1,'0',0,1),(2,8,57,NULL,'G','二','材料部分(第8~57項)','式',1,'0',0,2),(3,1,7,NULL,'P','三','利潤及管理費(第1~7項和之10%)','式',1,'0',10,3),(4,8,57,NULL,'P','四','利潤及管理費(第8~57項和之3%)','式',1,'0',3,4),(5,1,7,NULL,'S','五','工安衛生環保管理及措施費(第1~7項和之2%)','式',1,'0',2,5),(6,0,0,NULL,'T','六','營業稅(一~五項和之5%)','式',1,'0',5,6);
/*!40000 ALTER TABLE `profitfee_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `requestpayment_tab`
--

DROP TABLE IF EXISTS `requestpayment_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `requestpayment_tab` (
  `rp_installment` tinyint NOT NULL COMMENT '請款期數(PK)',
  `rp_date` date DEFAULT NULL COMMENT '請款日期',
  PRIMARY KEY (`rp_installment`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='請款歸檔';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `requestpayment_tab`
--

LOCK TABLES `requestpayment_tab` WRITE;
/*!40000 ALTER TABLE `requestpayment_tab` DISABLE KEYS */;
/*!40000 ALTER TABLE `requestpayment_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workratio1_tab`
--

DROP TABLE IF EXISTS `workratio1_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workratio1_tab` (
  `wr_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `wr_wt_id` int NOT NULL COMMENT '表格編號(FK)',
  `wr_item` int NOT NULL COMMENT '項次',
  `wr_multiplier` double NOT NULL COMMENT '乘數',
  `wr_content` varchar(255) NOT NULL COMMENT '內容',
  PRIMARY KEY (`wr_id`),
  UNIQUE KEY `wr_wt_id` (`wr_wt_id`,`wr_item`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='工作單價比例換算(困難度1)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workratio1_tab`
--

LOCK TABLES `workratio1_tab` WRITE;
/*!40000 ALTER TABLE `workratio1_tab` DISABLE KEYS */;
/*!40000 ALTER TABLE `workratio1_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workratio2_tab`
--

DROP TABLE IF EXISTS `workratio2_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workratio2_tab` (
  `wr_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `wr_wt_id` int NOT NULL COMMENT '表格編號(FK)',
  `wr_item` int NOT NULL COMMENT '項次',
  `wr_multiplier` double NOT NULL COMMENT '乘數',
  `wr_content` varchar(255) NOT NULL COMMENT '內容',
  PRIMARY KEY (`wr_id`),
  UNIQUE KEY `wr_wt_id` (`wr_wt_id`,`wr_item`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='工作單價比例換算(困難度2)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workratio2_tab`
--

LOCK TABLES `workratio2_tab` WRITE;
/*!40000 ALTER TABLE `workratio2_tab` DISABLE KEYS */;
/*!40000 ALTER TABLE `workratio2_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `worktable_tab`
--

DROP TABLE IF EXISTS `worktable_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `worktable_tab` (
  `wt_id` int NOT NULL AUTO_INCREMENT COMMENT '編號(PK)',
  `wt_item` varchar(255) NOT NULL COMMENT '表格編號',
  `wt_name` varchar(255) NOT NULL COMMENT '表格名稱',
  `wt_sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`wt_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='工作單價比例換算表(查表)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `worktable_tab`
--

LOCK TABLES `worktable_tab` WRITE;
/*!40000 ALTER TABLE `worktable_tab` DISABLE KEYS */;
/*!40000 ALTER TABLE `worktable_tab` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-27  0:00:17
